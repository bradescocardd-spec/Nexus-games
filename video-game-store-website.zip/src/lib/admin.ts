import { cookies } from "next/headers";

/**
 * Senha do painel administrativo.
 * Defina ADMIN_TOKEN nas variáveis de ambiente antes de publicar.
 */
export function adminToken() {
  return process.env.ADMIN_TOKEN?.trim() || "nexus-admin";
}

export function usingDefaultToken() {
  return !process.env.ADMIN_TOKEN?.trim();
}

const COOKIE = "nexus_admin";

export async function isAdmin() {
  const jar = await cookies();
  return jar.get(COOKIE)?.value === adminToken();
}

export async function setAdminCookie(token: string) {
  const jar = await cookies();
  jar.set(COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 8,
    path: "/",
  });
}

export async function clearAdminCookie() {
  const jar = await cookies();
  jar.delete(COOKIE);
}

export function unauthorized() {
  return Response.json({ error: "Acesso não autorizado." }, { status: 401 });
}
