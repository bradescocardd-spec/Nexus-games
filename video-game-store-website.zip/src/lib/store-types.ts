import type { Platform } from "./catalog";
import type { PaymentMethod } from "./payment";

export type CartItem = { gameId: string; platform: Platform; quantity: number };
export type Profile = { name: string; email: string; cpf?: string; phone?: string };

export type SavedOrder = {
  code: string;
  total: number;
  subtotal: number;
  discountAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  installments?: number;
  cardLast4?: string;
  cardBrand?: string;
  pixCode?: string;
  boletoCode?: string;
  createdAt: string;
  items: { gameId: string; title: string; platform: string; quantity: number; price: number }[];
};

export type DialogName =
  | "cart"
  | "checkout"
  | "reserve"
  | "profile"
  | "help"
  | "privacy"
  | "about"
  | "trailer"
  | "payment-settings"
  | "publish-guide"
  | "admin-orders"
  | null;

export async function sendJson(url: string, body: unknown) {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error || "Algo deu errado. Tente novamente.");
  return result;
}
