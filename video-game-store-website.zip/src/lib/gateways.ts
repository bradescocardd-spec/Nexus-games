import { db } from "@/db";
import { paymentSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { defaultPaymentSettings, type PaymentSettings } from "./payment";

export type GatewayProvider = "mercadopago" | "asaas" | "stripe" | "manual";

export type ResolvedConfig = PaymentSettings & {
  /** Credenciais efetivas (env tem prioridade sobre o banco) */
  mpToken: string;
  mpPublic: string;
  stripeSecret: string;
  stripePublic: string;
  asaasKey: string;
  pixKeyEffective: string;
  provider: GatewayProvider;
  credentialSource: "env" | "painel" | "nenhuma";
  isLive: boolean;
};

/** Base da API do Asaas conforme o modo de operação. */
export function asaasBase(mode: string) {
  return mode === "production"
    ? "https://api.asaas.com/v3"
    : "https://api-sandbox.asaas.com/v3";
}

/**
 * Carrega as configurações salvas no banco e sobrepõe com as variáveis de
 * ambiente, que sempre têm prioridade por serem mais seguras em produção.
 */
export async function resolvePaymentConfig(): Promise<ResolvedConfig> {
  let stored: PaymentSettings = defaultPaymentSettings;

  try {
    const rows = await db
      .select()
      .from(paymentSettings)
      .where(eq(paymentSettings.id, "default"))
      .limit(1);
    if (rows.length) {
      const r = rows[0];
      stored = {
        gatewayMode: (r.gatewayMode as "sandbox" | "production") ?? "sandbox",
        pixKey: r.pixKey ?? defaultPaymentSettings.pixKey,
        pixKeyType: (r.pixKeyType as "email" | "cpf" | "random") ?? "email",
        pixDiscountPercent: r.pixDiscountPercent ?? 5,
        mercadoPagoPublicKey: r.mercadoPagoPublicKey ?? "",
        mercadoPagoAccessToken: r.mercadoPagoAccessToken ?? "",
        stripePublishableKey: r.stripePublishableKey ?? "",
        stripeSecretKey: r.stripeSecretKey ?? "",
        asaasApiKey: r.asaasApiKey ?? "",
        merchantName: r.merchantName ?? defaultPaymentSettings.merchantName,
        merchantCity: r.merchantCity ?? defaultPaymentSettings.merchantCity,
        maxInstallments: r.maxInstallments ?? 12,
        freeInstallments: r.freeInstallments ?? 6,
      };
    }
  } catch {
    /* banco indisponível: segue com os padrões */
  }

  const envMpToken = process.env.MERCADO_PAGO_ACCESS_TOKEN?.trim() || "";
  const envMpPublic = process.env.MERCADO_PAGO_PUBLIC_KEY?.trim() || "";
  const envStripeSecret = process.env.STRIPE_SECRET_KEY?.trim() || "";
  const envStripePublic = process.env.STRIPE_PUBLISHABLE_KEY?.trim() || "";
  const envPix = process.env.PIX_CHAVE_PADRAO?.trim() || "";

  const envAsaas = process.env.ASAAS_API_KEY?.trim() || "";

  const mpToken = envMpToken || stored.mercadoPagoAccessToken || "";
  const mpPublic = envMpPublic || stored.mercadoPagoPublicKey || "";
  const stripeSecret = envStripeSecret || stored.stripeSecretKey || "";
  const stripePublic = envStripePublic || stored.stripePublishableKey || "";
  const asaasKey = envAsaas || stored.asaasApiKey || "";
  const pixKeyEffective = envPix || stored.pixKey || defaultPaymentSettings.pixKey;

  const provider: GatewayProvider = mpToken
    ? "mercadopago"
    : asaasKey
    ? "asaas"
    : stripeSecret
    ? "stripe"
    : "manual";

  const credentialSource: ResolvedConfig["credentialSource"] =
    envMpToken || envStripeSecret || envAsaas
      ? "env"
      : stored.mercadoPagoAccessToken || stored.stripeSecretKey || stored.asaasApiKey
      ? "painel"
      : "nenhuma";

  return {
    ...stored,
    mpToken,
    mpPublic,
    stripeSecret,
    stripePublic,
    asaasKey,
    pixKeyEffective,
    provider,
    credentialSource,
    isLive: stored.gatewayMode === "production" && provider !== "manual",
  };
}

/* ------------------------------------------------------------------ */
/* Mercado Pago                                                        */
/* ------------------------------------------------------------------ */

type MpPixResult = {
  ok: true;
  providerPaymentId: string;
  qrCode: string;
  qrCodeBase64: string | null;
  ticketUrl: string | null;
};

type GatewayError = { ok: false; error: string };

export async function createMercadoPagoPix(params: {
  token: string;
  amountCents: number;
  description: string;
  email: string;
  firstName: string;
  cpf?: string;
  orderCode: string;
}): Promise<MpPixResult | GatewayError> {
  try {
    const body: Record<string, unknown> = {
      transaction_amount: Number((params.amountCents / 100).toFixed(2)),
      description: params.description.slice(0, 250),
      payment_method_id: "pix",
      external_reference: params.orderCode,
      payer: {
        email: params.email,
        first_name: params.firstName.split(" ")[0] || "Cliente",
        ...(params.cpf
          ? { identification: { type: "CPF", number: params.cpf.replace(/\D/g, "") } }
          : {}),
      },
    };

    const response = await fetch("https://api.mercadopago.com/v1/payments", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${params.token}`,
        "Content-Type": "application/json",
        "X-Idempotency-Key": params.orderCode,
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000),
    });

    const data = await response.json();

    if (!response.ok) {
      return {
        ok: false,
        error: data?.message || "O Mercado Pago recusou a criação do PIX.",
      };
    }

    const tx = data?.point_of_interaction?.transaction_data;
    if (!tx?.qr_code) {
      return { ok: false, error: "O Mercado Pago não retornou o código PIX." };
    }

    return {
      ok: true,
      providerPaymentId: String(data.id),
      qrCode: tx.qr_code,
      qrCodeBase64: tx.qr_code_base64 ?? null,
      ticketUrl: tx.ticket_url ?? null,
    };
  } catch (error) {
    return {
      ok: false,
      error:
        error instanceof Error
          ? `Falha ao conectar no Mercado Pago: ${error.message}`
          : "Falha ao conectar no Mercado Pago.",
    };
  }
}

export async function testMercadoPago(token: string) {
  try {
    const response = await fetch("https://api.mercadopago.com/users/me", {
      headers: { Authorization: `Bearer ${token}` },
      signal: AbortSignal.timeout(12000),
    });
    const data = await response.json();
    if (!response.ok) {
      return { ok: false as const, error: data?.message || "Credencial inválida." };
    }
    return {
      ok: true as const,
      account: data?.nickname || data?.email || `ID ${data?.id}`,
      country: data?.site_id || "",
      live: !token.startsWith("TEST-"),
    };
  } catch (error) {
    return {
      ok: false as const,
      error: error instanceof Error ? error.message : "Erro de conexão.",
    };
  }
}

/* ------------------------------------------------------------------ */
/* Asaas — abre conta com CPF, sem precisar de CNPJ                    */
/* ------------------------------------------------------------------ */

async function asaasFetch(
  key: string,
  mode: string,
  path: string,
  init?: RequestInit
) {
  return fetch(`${asaasBase(mode)}${path}`, {
    ...init,
    headers: {
      access_token: key,
      "Content-Type": "application/json",
      ...(init?.headers || {}),
    },
    signal: AbortSignal.timeout(15000),
  });
}

/** Busca (ou cria) o cliente no Asaas, exigido antes de gerar a cobrança. */
async function getOrCreateAsaasCustomer(params: {
  key: string;
  mode: string;
  name: string;
  email: string;
  cpf: string;
}): Promise<{ ok: true; id: string } | GatewayError> {
  const cpf = params.cpf.replace(/\D/g, "");
  try {
    if (cpf) {
      const search = await asaasFetch(
        params.key,
        params.mode,
        `/customers?cpfCnpj=${cpf}`
      );
      const found = await search.json();
      if (search.ok && Array.isArray(found?.data) && found.data.length) {
        return { ok: true, id: String(found.data[0].id) };
      }
    }

    const created = await asaasFetch(params.key, params.mode, "/customers", {
      method: "POST",
      body: JSON.stringify({
        name: params.name,
        email: params.email,
        ...(cpf ? { cpfCnpj: cpf } : {}),
      }),
    });
    const data = await created.json();
    if (!created.ok || !data?.id) {
      return {
        ok: false,
        error:
          data?.errors?.[0]?.description ||
          "O Asaas não aceitou o cadastro do cliente (verifique o CPF).",
      };
    }
    return { ok: true, id: String(data.id) };
  } catch (error) {
    return {
      ok: false,
      error: error instanceof Error ? `Asaas: ${error.message}` : "Falha no Asaas.",
    };
  }
}

export async function createAsaasPix(params: {
  key: string;
  mode: string;
  amountCents: number;
  description: string;
  name: string;
  email: string;
  cpf: string;
  orderCode: string;
}): Promise<MpPixResult | GatewayError> {
  const customer = await getOrCreateAsaasCustomer({
    key: params.key,
    mode: params.mode,
    name: params.name,
    email: params.email,
    cpf: params.cpf,
  });
  if (!customer.ok) return customer;

  try {
    const dueDate = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    const created = await asaasFetch(params.key, params.mode, "/payments", {
      method: "POST",
      body: JSON.stringify({
        customer: customer.id,
        billingType: "PIX",
        value: Number((params.amountCents / 100).toFixed(2)),
        dueDate,
        description: params.description.slice(0, 500),
        externalReference: params.orderCode,
      }),
    });
    const payment = await created.json();
    if (!created.ok || !payment?.id) {
      return {
        ok: false,
        error:
          payment?.errors?.[0]?.description || "O Asaas recusou a criação da cobrança.",
      };
    }

    const qrResp = await asaasFetch(
      params.key,
      params.mode,
      `/payments/${payment.id}/pixQrCode`
    );
    const qr = await qrResp.json();
    if (!qrResp.ok || !qr?.payload) {
      return { ok: false, error: "O Asaas não retornou o código PIX." };
    }

    return {
      ok: true,
      providerPaymentId: String(payment.id),
      qrCode: String(qr.payload),
      qrCodeBase64: qr.encodedImage ? String(qr.encodedImage) : null,
      ticketUrl: payment.invoiceUrl ? String(payment.invoiceUrl) : null,
    };
  } catch (error) {
    return {
      ok: false,
      error:
        error instanceof Error
          ? `Falha ao conectar no Asaas: ${error.message}`
          : "Falha ao conectar no Asaas.",
    };
  }
}

export async function getAsaasPaymentStatus(key: string, mode: string, id: string) {
  try {
    const resp = await asaasFetch(key, mode, `/payments/${id}`);
    const data = await resp.json();
    if (!resp.ok) return { ok: false as const };
    return { ok: true as const, status: String(data?.status || "") };
  } catch {
    return { ok: false as const };
  }
}

export async function testAsaas(key: string, mode: string) {
  try {
    const resp = await asaasFetch(key, mode, "/myAccount/commercialInfo");
    const data = await resp.json();
    if (!resp.ok) {
      return {
        ok: false as const,
        error:
          data?.errors?.[0]?.description ||
          "Chave inválida para este modo (teste x produção).",
      };
    }
    return {
      ok: true as const,
      account: data?.name || data?.email || "Conta Asaas",
      live: mode === "production",
    };
  } catch (error) {
    return {
      ok: false as const,
      error: error instanceof Error ? error.message : "Erro de conexão.",
    };
  }
}

/* ------------------------------------------------------------------ */
/* Stripe                                                              */
/* ------------------------------------------------------------------ */

export async function createStripePaymentIntent(params: {
  secret: string;
  amountCents: number;
  description: string;
  email: string;
  orderCode: string;
}): Promise<
  | { ok: true; providerPaymentId: string; clientSecret: string }
  | GatewayError
> {
  try {
    const form = new URLSearchParams();
    form.set("amount", String(params.amountCents));
    form.set("currency", "brl");
    form.set("description", params.description.slice(0, 250));
    form.set("receipt_email", params.email);
    form.set("metadata[order_code]", params.orderCode);
    form.set("automatic_payment_methods[enabled]", "true");

    const response = await fetch("https://api.stripe.com/v1/payment_intents", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${params.secret}`,
        "Content-Type": "application/x-www-form-urlencoded",
        "Idempotency-Key": params.orderCode,
      },
      body: form.toString(),
      signal: AbortSignal.timeout(15000),
    });

    const data = await response.json();
    if (!response.ok) {
      return { ok: false, error: data?.error?.message || "A Stripe recusou a cobrança." };
    }

    return {
      ok: true,
      providerPaymentId: String(data.id),
      clientSecret: String(data.client_secret),
    };
  } catch (error) {
    return {
      ok: false,
      error:
        error instanceof Error
          ? `Falha ao conectar na Stripe: ${error.message}`
          : "Falha ao conectar na Stripe.",
    };
  }
}

export async function testStripe(secret: string) {
  try {
    const response = await fetch("https://api.stripe.com/v1/balance", {
      headers: { Authorization: `Bearer ${secret}` },
      signal: AbortSignal.timeout(12000),
    });
    const data = await response.json();
    if (!response.ok) {
      return { ok: false as const, error: data?.error?.message || "Credencial inválida." };
    }
    return {
      ok: true as const,
      account: "Conta Stripe conectada",
      live: data?.livemode === true,
    };
  } catch (error) {
    return {
      ok: false as const,
      error: error instanceof Error ? error.message : "Erro de conexão.",
    };
  }
}
