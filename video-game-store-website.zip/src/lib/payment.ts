export type PaymentMethod = "pix" | "credit_card" | "boleto";

export type CardDetails = {
  number: string;
  name: string;
  expiry: string;
  cvv: string;
  installments: number;
  cpf: string;
};

export type PaymentSettings = {
  gatewayMode: "sandbox" | "production";
  pixKey: string;
  pixKeyType: "email" | "cpf" | "random";
  pixDiscountPercent: number;
  mercadoPagoPublicKey: string;
  mercadoPagoAccessToken: string;
  stripePublishableKey: string;
  stripeSecretKey: string;
  asaasApiKey: string;
  merchantName: string;
  merchantCity: string;
  maxInstallments: number;
  freeInstallments: number;
};

export const defaultPaymentSettings: PaymentSettings = {
  gatewayMode: "sandbox",
  pixKey: "pagamentos@nexusgames.com.br",
  pixKeyType: "email",
  pixDiscountPercent: 5,
  mercadoPagoPublicKey: "",
  mercadoPagoAccessToken: "",
  stripePublishableKey: "",
  stripeSecretKey: "",
  asaasApiKey: "",
  merchantName: "NEXUS GAMES",
  merchantCity: "SAO PAULO",
  maxInstallments: 12,
  freeInstallments: 6,
};

// Detect card brand
export function detectCardBrand(num: string): string {
  const clean = num.replace(/\D/g, "");
  if (/^4/.test(clean)) return "Visa";
  if (/^(5[1-5]|222[1-9]|22[3-9]|2[3-6]|27[01]|2720)/.test(clean)) return "Mastercard";
  if (/^(4011|438935|451416|4576|504175|5067|5090|627780|636297|636368|650|6516|6550)/.test(clean)) return "Elo";
  if (/^(34|37)/.test(clean)) return "American Express";
  if (/^(606282|3841)/.test(clean)) return "Hipercard";
  return "Cartão";
}

// Generate realistic PIX EMV payload (BR Code)
export function generatePixPayload(key: string, name: string, city: string, amount: number, txid: string): string {
  const f = (id: string, val: string) => `${id}${val.length.toString().padStart(2, "0")}${val}`;
  const amountStr = (amount / 100).toFixed(2);
  const merchantAccount = `${f("00", "br.gov.bcb.pix")}${f("01", key)}`;
  const additionalData = f("05", txid.slice(0, 25));

  let payload =
    f("00", "01") +
    f("01", "12") +
    f("26", merchantAccount) +
    f("52", "0000") +
    f("53", "986") +
    f("54", amountStr) +
    f("58", "BR") +
    f("59", name.slice(0, 25).toUpperCase()) +
    f("60", city.slice(0, 15).toUpperCase()) +
    f("62", additionalData) +
    "6304";

  // CRC16 CCITT
  let crc = 0xffff;
  for (let i = 0; i < payload.length; i++) {
    crc ^= payload.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if ((crc & 0x8000) !== 0) {
        crc = (crc << 1) ^ 0x1021;
      } else {
        crc = crc << 1;
      }
    }
  }
  const hexCrc = (crc & 0xffff).toString(16).toUpperCase().padStart(4, "0");
  return payload + hexCrc;
}

/*
 * Boleto removido de propósito.
 *
 * Uma "linha digitável" só é válida se for emitida por um banco ou por uma
 * processadora registrada. Gerar números aleatórios produziria um boleto
 * impagável: o cliente acharia que pagou e o dinheiro nunca chegaria.
 *
 * O boleto só aparece no checkout quando há uma gateway conectada
 * (Asaas ou Mercado Pago), que emite o documento de verdade.
 */

/**
 * Gera um QR Code REAL (escaneável) em PNG base64 a partir do payload PIX.
 * Executado no servidor para não pesar no bundle do cliente.
 */
export async function generateRealQrBase64(text: string): Promise<string | null> {
  try {
    const QRCode = (await import("qrcode")).default;
    const dataUrl = await QRCode.toDataURL(text, {
      errorCorrectionLevel: "M",
      margin: 1,
      width: 420,
      color: { dark: "#0b1322", light: "#ffffff" },
    });
    return dataUrl.replace(/^data:image\/png;base64,/, "");
  } catch {
    return null;
  }
}

// Fallback visual (não escaneável) usado apenas se a geração real falhar
export function getQrMatrix(text: string): { x: number; y: number }[] {
  let hash = 0;
  for (let i = 0; i < text.length; i++) {
    hash = (hash << 5) - hash + text.charCodeAt(i);
    hash |= 0;
  }
  const size = 25;
  const points: { x: number; y: number }[] = [];

  const addMarker = (startX: number, startY: number) => {
    for (let x = 0; x < 7; x++) {
      for (let y = 0; y < 7; y++) {
        if (
          x === 0 ||
          x === 6 ||
          y === 0 ||
          y === 6 ||
          (x >= 2 && x <= 4 && y >= 2 && y <= 4)
        ) {
          points.push({ x: startX + x, y: startY + y });
        }
      }
    }
  };

  addMarker(1, 1);
  addMarker(size - 8, 1);
  addMarker(1, size - 8);

  for (let x = 0; x < size; x++) {
    for (let y = 0; y < size; y++) {
      if ((x < 9 && y < 9) || (x > size - 10 && y < 9) || (x < 9 && y > size - 10)) {
        continue;
      }
      const val = Math.abs(Math.sin(x * 12.9898 + y * 78.233 + hash) * 43758.5453);
      if (val - Math.floor(val) > 0.44) {
        points.push({ x, y });
      }
    }
  }
  return points;
}
