import { pgTable, uuid, text, integer, timestamp, jsonb } from "drizzle-orm/pg-core";

export type OrderItem = {
  gameId: string;
  title: string;
  platform: string;
  quantity: number;
  price: number;
};

export const orders = pgTable("nexus_orders", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull().unique(),
  sessionId: uuid("session_id").notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  cpf: text("cpf"),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  subtotal: integer("subtotal").notNull().default(0),
  discountAmount: integer("discount_amount").notNull().default(0),
  total: integer("total").notNull(),
  paymentMethod: text("payment_method").notNull().default("pix"),
  paymentStatus: text("payment_status").notNull().default("Aprovado"),
  installments: integer("installments").default(1),
  cardLast4: text("card_last4"),
  cardBrand: text("card_brand"),
  pixCode: text("pix_code"),
  boletoCode: text("boleto_code"),
  provider: text("provider").notNull().default("manual"),
  providerPaymentId: text("provider_payment_id"),
  providerQrBase64: text("provider_qr_base64"),
  providerUrl: text("provider_url"),
  paidAt: timestamp("paid_at", { withTimezone: true }),
  adminNote: text("admin_note"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const reservations = pgTable("nexus_reservations", {
  id: uuid("id").defaultRandom().primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  phone: text("phone"),
  game: text("game").notNull().default("Grand Theft Auto VI"),
  platform: text("platform").notNull().default("PS5"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const subscribers = pgTable("nexus_subscribers", {
  email: text("email").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const paymentSettings = pgTable("nexus_payment_settings", {
  id: text("id").primaryKey().default("default"),
  gatewayMode: text("gateway_mode").notNull().default("sandbox"), // "sandbox" | "production"
  pixKey: text("pix_key").notNull().default("pagamentos@nexusgames.com.br"),
  pixKeyType: text("pix_key_type").notNull().default("email"), // "email" | "cpf" | "random"
  pixDiscountPercent: integer("pix_discount_percent").notNull().default(5),
  mercadoPagoPublicKey: text("mp_public_key").default(""),
  mercadoPagoAccessToken: text("mp_access_token").default(""),
  stripePublishableKey: text("stripe_pk").default(""),
  stripeSecretKey: text("stripe_sk").default(""),
  asaasApiKey: text("asaas_api_key").default(""),
  merchantName: text("merchant_name").notNull().default("NEXUS GAMES"),
  merchantCity: text("merchant_city").notNull().default("SAO PAULO"),
  maxInstallments: integer("max_installments").notNull().default(12),
  freeInstallments: integer("free_installments").notNull().default(6),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});
