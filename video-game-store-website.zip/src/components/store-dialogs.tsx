"use client";

import Image from "next/image";
import { useCallback, useEffect, useState, type FormEvent } from "react";
import {
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Copy,
  CreditCard,
  DollarSign,
  Download,
  ExternalLink,
  Gamepad2,
  Globe,
  Heart,
  HelpCircle,
  Info,
  KeyRound,
  Layers,
  LoaderCircle,
  LockKeyhole,
  Minus,
  Package,
  Plus,
  QrCode,
  Receipt,
  RefreshCw,
  Server,
  Settings,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  Sparkles,
  Star,
  Trash2,
  Wallet,
  Zap,
} from "lucide-react";
import { games, money, pixPrice, platformLabel, discount, type Game, type Platform } from "@/lib/catalog";
import {
  sendJson,
  type CartItem,
  type DialogName,
  type Profile,
  type SavedOrder,
} from "@/lib/store-types";
import {
  type PaymentMethod,
  type PaymentSettings,
  defaultPaymentSettings,
  detectCardBrand,
  getQrMatrix,
} from "@/lib/payment";

function PixQrCanvas({ text }: { text: string }) {
  const points = getQrMatrix(text);
  const size = 25;
  const cellSize = 6;
  const total = size * cellSize;

  return (
    <div className="pix-qr-container">
      <svg
        viewBox={`0 0 ${total} ${total}`}
        width="140"
        height="140"
        className="pix-svg-canvas"
        role="img"
        aria-label="QR Code PIX"
      >
        <rect width={total} height={total} fill="#ffffff" rx="6" />
        {points.map((pt, i) => (
          <rect
            key={i}
            x={pt.x * cellSize}
            y={pt.y * cellSize}
            width={cellSize}
            height={cellSize}
            fill="#0b1322"
          />
        ))}
      </svg>
    </div>
  );
}
import { Dialog, PlatformIcon } from "./store-ui";
import { AdminOrdersPanel } from "./admin-orders";

type Props = {
  dialog: DialogName;
  onClose: () => void;
  setDialog: (dialog: DialogName) => void;
  cart: CartItem[];
  onQuantity: (gameId: string, platform: Platform, quantity: number) => void;
  clearCart: () => void;
  profile: Profile;
  saveProfile: (profile: Profile) => void;
};

function Feedback({ error }: { error: string }) {
  return error ? (
    <p className="form-error" role="alert">
      <Info size={16} />
      {error}
    </p>
  ) : null;
}

function Submit({ busy, children }: { busy: boolean; children: React.ReactNode }) {
  return (
    <button type="submit" className="button button-primary button-full" disabled={busy}>
      {busy ? (
        <>
          <LoaderCircle size={18} className="spin" /> Processando...
        </>
      ) : (
        children
      )}
    </button>
  );
}

export function StoreDialogs(props: Props) {
  if (!props.dialog) return null;
  return (
    <Dialog
      onClose={props.onClose}
      drawer={props.dialog === "cart"}
      wide={
        props.dialog === "trailer" ||
        props.dialog === "checkout" ||
        props.dialog === "payment-settings" ||
        props.dialog === "publish-guide" ||
        props.dialog === "admin-orders"
      }
    >
      {props.dialog === "cart" ? (
        <CartPanel {...props} />
      ) : props.dialog === "checkout" ? (
        <Checkout {...props} />
      ) : props.dialog === "reserve" ? (
        <Reservation profile={props.profile} saveProfile={props.saveProfile} onClose={props.onClose} />
      ) : props.dialog === "profile" ? (
        <ProfilePanel profile={props.profile} saveProfile={props.saveProfile} setDialog={props.setDialog} />
      ) : props.dialog === "trailer" ? (
        <Trailer />
      ) : props.dialog === "payment-settings" ? (
        <PaymentSettingsPanel onClose={props.onClose} setDialog={props.setDialog} />
      ) : props.dialog === "admin-orders" ? (
        <AdminOrdersPanel />
      ) : props.dialog === "publish-guide" ? (
        <PublishGuidePanel onClose={props.onClose} />
      ) : (
        <Information kind={props.dialog} />
      )}
    </Dialog>
  );
}

function CartPanel({ cart, onQuantity, setDialog, onClose }: Props) {
  const subtotal = cart.reduce(
    (sum, item) => sum + (games.find((game) => game.id === item.gameId)?.price ?? 0) * item.quantity,
    0
  );
  const pixDiscount = Math.round(subtotal * 0.05);

  return (
    <>
      <span className="dialog-eyebrow">
        <ShoppingBag size={17} /> SEU CARRINHO DE JOGOS
      </span>
      <h2 id="dialog-title">
        Jogos Escolhidos{" "}
        <span className="count-pill">{cart.reduce((sum, item) => sum + item.quantity, 0)}</span>
      </h2>
      {!cart.length ? (
        <div className="empty-state">
          <div className="empty-icon">
            <ShoppingCart size={38} />
          </div>
          <h3>Seu carrinho está vazio.</h3>
          <p>Explore nosso catálogo com descontos imperdíveis e monte sua coleção.</p>
          <button className="button button-primary" onClick={onClose}>
            Explorar Jogos em Oferta <ArrowRight size={17} />
          </button>
        </div>
      ) : (
        <>
          <p className="dialog-description">Preços promocionais imperdíveis e entrega imediata.</p>
          <div className="cart-lines">
            {cart.map((item) => {
              const game = games.find((g) => g.id === item.gameId);
              if (!game) return null;
              return (
                <article className="cart-line" key={`${item.gameId}-${item.platform}`}>
                  <Image src={game.image} width={75} height={90} alt={`Capa de ${game.title}`} />
                  <div className="cart-line-info">
                    <span className={`small-platform ${item.platform === "Xbox" ? "xbox-text" : ""}`}>
                      <PlatformIcon platform={item.platform} size={13} />
                      {item.platform}
                    </span>
                    <h3>{game.title}</h3>
                    <div className="cart-price-tag">
                      <strong>{money(game.price)}</strong>
                      <del>{money(game.originalPrice)}</del>
                    </div>
                    <div className="quantity-controls">
                      <button
                        onClick={() => onQuantity(item.gameId, item.platform, item.quantity - 1)}
                        aria-label={`Diminuir quantidade de ${game.title}`}
                      >
                        <Minus size={13} />
                      </button>
                      <span>{item.quantity}</span>
                      <button
                        disabled={item.quantity >= 10}
                        onClick={() => onQuantity(item.gameId, item.platform, item.quantity + 1)}
                        aria-label={`Aumentar quantidade de ${game.title}`}
                      >
                        <Plus size={13} />
                      </button>
                    </div>
                  </div>
                  <button
                    className="remove-item icon-button"
                    onClick={() => onQuantity(item.gameId, item.platform, 0)}
                    aria-label={`Remover ${game.title}`}
                  >
                    <Trash2 size={17} />
                  </button>
                </article>
              );
            })}
          </div>

          <div className="cart-summary">
            <div>
              <span>Subtotal ({cart.reduce((s, i) => s + i.quantity, 0)} itens)</span>
              <span>{money(subtotal)}</span>
            </div>
            <div className="pix-benefit-row">
              <span>
                <Zap size={14} className="orange-text" /> Pagando no PIX (5% OFF)
              </span>
              <strong className="green-text">- {money(pixDiscount)}</strong>
            </div>
            <div className="summary-total">
              <span>Total no PIX</span>
              <strong>{money(subtotal - pixDiscount)}</strong>
            </div>
            <span className="cart-card-total">
              ou {money(subtotal)} em até 6x sem juros no cartão
            </span>
          </div>

          <button
            className="button button-primary button-full"
            onClick={() => setDialog("checkout")}
          >
            Avançar para Pagamento <ArrowRight size={18} />
          </button>
          <button className="text-button continue-shopping" onClick={onClose}>
            Continuar comprando
          </button>
          <div className="cart-badges">
            <span>
              <ShieldCheck size={14} /> Pagamento 100% Seguro
            </span>
            <span>
              <Zap size={14} /> Envio Digital Instantâneo
            </span>
          </div>
        </>
      )}
    </>
  );
}

function Checkout({ cart, clearCart, profile, saveProfile, setDialog }: Props) {
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [cpf, setCpf] = useState(profile.cpf || "");
  const [phone, setPhone] = useState(profile.phone || "");
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>("pix");
  const [methods, setMethods] = useState({ pix: true, credit_card: false, boleto: false });
  const [discountPercent, setDiscountPercent] = useState(5);

  useEffect(() => {
    fetch("/api/settings/public")
      .then((r) => r.json())
      .then((d) => {
        if (d.methods) setMethods(d.methods);
        if (typeof d.pixDiscountPercent === "number") setDiscountPercent(d.pixDiscountPercent);
      })
      .catch(() => {});
  }, []);

  // Card fields
  const [cardNumber, setCardNumber] = useState("");
  const [cardHolder, setCardHolder] = useState("");
  const [cardExpiry, setCardExpiry] = useState("");
  const [cardCvv, setCardCvv] = useState("");
  const [installments, setInstallments] = useState(1);

  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [pixConfirmed, setPixConfirmed] = useState(false);
  const [pixConfirmBusy, setPixConfirmBusy] = useState(false);
  const [pixCheckNote, setPixCheckNote] = useState("");

  const [result, setResult] = useState<{
    code: string;
    subtotal: number;
    discountAmount: number;
    discountPercent?: number;
    total: number;
    paymentMethod: string;
    paymentStatus: string;
    pixCode?: string;
    boletoCode?: string;
    installments?: number;
    cardLast4?: string;
    cardBrand?: string;
    provider?: string;
    providerQrBase64?: string | null;
    providerUrl?: string | null;
    gatewayMode?: string;
    isLive?: boolean;
    gatewayWarning?: string | null;
    message: string;
  } | null>(null);

  const subtotal = cart.reduce(
    (sum, item) => sum + (games.find((g) => g.id === item.gameId)?.price ?? 0) * item.quantity,
    0
  );
  const pixDiscount =
    paymentMethod === "pix" ? Math.round((subtotal * discountPercent) / 100) : 0;
  const currentTotal = Math.max(0, subtotal - pixDiscount);

  // Formats
  const handleCpfChange = (val: string) => {
    const raw = val.replace(/\D/g, "").slice(0, 11);
    if (raw.length <= 3) setCpf(raw);
    else if (raw.length <= 6) setCpf(`${raw.slice(0, 3)}.${raw.slice(3)}`);
    else if (raw.length <= 9) setCpf(`${raw.slice(0, 3)}.${raw.slice(3, 6)}.${raw.slice(6)}`);
    else setCpf(`${raw.slice(0, 3)}.${raw.slice(3, 6)}.${raw.slice(6, 9)}-${raw.slice(9)}`);
  };

  const handleCardNumberChange = (val: string) => {
    const raw = val.replace(/\D/g, "").slice(0, 16);
    const parts = raw.match(/[\s\S]{1,4}/g) || [];
    setCardNumber(parts.join(" "));
  };

  const handleExpiryChange = (val: string) => {
    const raw = val.replace(/\D/g, "").slice(0, 4);
    if (raw.length <= 2) setCardExpiry(raw);
    else setCardExpiry(`${raw.slice(0, 2)}/${raw.slice(2)}`);
  };

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");

    try {
      const data = await sendJson("/api/orders", {
        name,
        email,
        cpf,
        phone,
        paymentMethod,
        cardNumber,
        cardHolder,
        cardExpiry,
        cardCvv,
        installments,
        items: cart,
      });

      setResult(data);
      saveProfile({ name: name.trim(), email: email.trim(), cpf, phone });
      clearCart();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Tente novamente.");
    } finally {
      setBusy(false);
    }
  }

  const copyPixCode = () => {
    if (result?.pixCode) {
      navigator.clipboard.writeText(result.pixCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    }
  };

  async function checkPixStatus(simulate: boolean) {
    if (!result?.code) return;
    setPixConfirmBusy(true);
    setPixCheckNote("");
    try {
      const resp = await fetch("/api/orders", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code: result.code, simulate }),
      });
      const data = await resp.json();
      if (data.approved) {
        setPixConfirmed(true);
      } else {
        setPixCheckNote(
          data.note || "Pagamento ainda não identificado. Tente novamente em instantes."
        );
      }
    } catch {
      setPixCheckNote("Não foi possível consultar o status agora.");
    } finally {
      setPixConfirmBusy(false);
    }
  }

  if (result) {
    return (
      <div className="checkout-success-container">
        <div className="success-icon">
          <CheckCircle2 size={46} />
        </div>
        <span className="dialog-eyebrow">PAGAMENTO CONFIGURADO</span>
        <h2 id="dialog-title">
          {result.paymentMethod === "credit_card"
            ? "Pagamento Aprovado!"
            : result.paymentMethod === "pix"
            ? "Código PIX Gerado com Sucesso!"
            : "Boleto Bancário Gerado!"}
        </h2>
        <p className="dialog-description">{result.message}</p>

        <div className="order-summary-box">
          <div className="order-code-row">
            <div>
              <small>NÚMERO DO PEDIDO</small>
              <strong>{result.code}</strong>
            </div>
            <span
              className={`status-pill ${
                result.paymentMethod === "credit_card" || pixConfirmed
                  ? "status-approved"
                  : "status-pending"
              }`}
            >
              {pixConfirmed ? "PIX Confirmado" : result.paymentStatus}
            </span>
          </div>

          <div className="order-values-row">
            <div>
              <span>Subtotal</span>
              <span>{money(result.subtotal)}</span>
            </div>
            {result.discountAmount > 0 && (
              <div className="green-text">
                <span>Desconto PIX ({result.discountPercent ?? 5}%)</span>
                <span>- {money(result.discountAmount)}</span>
              </div>
            )}
            <div className="order-total-highlight">
              <span>Valor Total</span>
              <strong>{money(result.total)}</strong>
            </div>
          </div>

          {result.paymentMethod === "pix" && (
            <div className="pix-payment-box">
              <div className="gateway-origin-tag">
                {result.provider === "mercadopago" ? (
                  <>
                    <ShieldCheck size={13} className="green-text" /> PIX oficial gerado pelo{" "}
                    <strong>Mercado Pago</strong> — baixa automática ativada
                  </>
                ) : (
                  <>
                    <Info size={13} /> PIX gerado com sua chave cadastrada —{" "}
                    <strong>conciliação manual</strong>
                  </>
                )}
              </div>

              {result.gatewayWarning && (
                <p className="gateway-warning" role="alert">
                  <Info size={14} /> {result.gatewayWarning}
                </p>
              )}

              <div className="pix-qr-area">
                {result.providerQrBase64 ? (
                  <div className="pix-qr-container">
                    {/* QR Code oficial retornado pelo gateway */}
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={`data:image/png;base64,${result.providerQrBase64}`}
                      alt="QR Code PIX oficial"
                      className="pix-svg-canvas"
                    />
                  </div>
                ) : (
                  <PixQrCanvas text={result.pixCode || "PIX"} />
                )}
                <div className="pix-instructions">
                  <h4>Pague com o PIX no app do seu banco</h4>
                  <ol>
                    <li>Abra o aplicativo do seu banco favorito</li>
                    <li>Escolha a opção <strong>PIX Copia e Cola</strong> ou leia o QR Code</li>
                    <li>Confirme o valor de <strong>{money(result.total)}</strong></li>
                  </ol>
                  {result.providerUrl && (
                    <a
                      className="ticket-link"
                      href={result.providerUrl}
                      target="_blank"
                      rel="noreferrer"
                    >
                      Abrir comprovante oficial <ExternalLink size={12} />
                    </a>
                  )}
                </div>
              </div>

              <div className="pix-copy-section">
                <input readOnly value={result.pixCode} className="pix-code-input" />
                <button
                  type="button"
                  className="button button-secondary copy-pix-btn"
                  onClick={copyPixCode}
                >
                  {copied ? (
                    <>
                      <Check size={16} className="green-text" /> Copiado!
                    </>
                  ) : (
                    <>
                      <Copy size={16} /> Copiar Código PIX
                    </>
                  )}
                </button>
              </div>

              {!pixConfirmed ? (
                <div className="pix-simulation-bar">
                  {pixCheckNote && (
                    <p className="pix-check-note" role="status">
                      {pixCheckNote}
                    </p>
                  )}
                  <div className="pix-check-actions">
                    <button
                      className="button button-primary"
                      onClick={() => checkPixStatus(false)}
                      disabled={pixConfirmBusy}
                    >
                      {pixConfirmBusy ? (
                        <LoaderCircle size={16} className="spin" />
                      ) : (
                        <RefreshCw size={16} />
                      )}
                      Já paguei, verificar agora
                    </button>
                    {result.gatewayMode !== "production" && (
                      <button
                        className="button button-secondary"
                        onClick={() => checkPixStatus(true)}
                        disabled={pixConfirmBusy}
                      >
                        <CheckCircle2 size={16} /> Simular aprovação (modo teste)
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                <div className="pix-confirmed-alert">
                  <CheckCircle2 size={20} className="green-text" />
                  <strong>Pagamento PIX confirmado com sucesso! Licença liberada.</strong>
                </div>
              )}
            </div>
          )}

          {result.paymentMethod === "credit_card" && (
            <div className="credit-card-success-box">
              <CreditCard size={28} className="orange-text" />
              <div>
                <strong>
                  {result.cardBrand} final {result.cardLast4}
                </strong>
                <p>
                  Parcelado em {result.installments}x de{" "}
                  {money(Math.round(result.total / (result.installments || 1)))} sem juros
                </p>
              </div>
            </div>
          )}

          {result.paymentMethod === "boleto" && (
            <div className="boleto-box">
              <Receipt size={28} className="orange-text" />
              <div>
                <small>LINHA DIGITÁVEL DO BOLETO</small>
                <code>{result.boletoCode}</code>
                <p>Vencimento em 3 dias úteis. Pague em qualquer agência ou internet banking.</p>
              </div>
            </div>
          )}
        </div>

        <div className="order-actions-row">
          <button
            className="button button-primary button-full"
            onClick={() => setDialog("profile")}
          >
            Ver em Meus Pedidos <ArrowRight size={17} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <>
      <span className="dialog-eyebrow">
        <LockKeyhole size={17} /> CHECKOUT SEGURO & PAGAMENTO
      </span>
      <h2 id="dialog-title">Finalizar Pedido</h2>
      <p className="dialog-description">
        Escolha sua forma de pagamento preferida. Descontos e parcelamento configurados.
      </p>

      <form onSubmit={submit} className="checkout-layout">
        {/* Left Column: Customer details & Payment selector */}
        <div className="checkout-form-col">
          <fieldset className="checkout-fieldset">
            <legend>1. Dados do Comprador</legend>
            <div className="grid-2-col">
              <label>
                Nome Completo
                <input
                  required
                  minLength={2}
                  maxLength={100}
                  autoComplete="name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Seu nome"
                />
              </label>
              <label>
                E-mail para Recebimento
                <input
                  required
                  type="email"
                  maxLength={254}
                  autoComplete="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="voce@email.com"
                />
              </label>
            </div>
            <div className="grid-2-col">
              <label>
                CPF (para nota fiscal)
                <input
                  required
                  value={cpf}
                  onChange={(e) => handleCpfChange(e.target.value)}
                  placeholder="000.000.000-00"
                />
              </label>
              <label>
                Telefone / WhatsApp (opcional)
                <input
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="(11) 99999-9999"
                />
              </label>
            </div>
          </fieldset>

          <fieldset className="checkout-fieldset">
            <legend>2. Forma de Pagamento</legend>
            <div className="payment-options-grid">
              <button
                type="button"
                className={`payment-option-card ${paymentMethod === "pix" ? "selected" : ""}`}
                onClick={() => setPaymentMethod("pix")}
              >
                <div className="option-header">
                  <div className="option-icon-title">
                    <QrCode size={22} className="orange-text" />
                    <strong>PIX Instantâneo</strong>
                  </div>
                  <span className="pix-badge">{discountPercent}% OFF</span>
                </div>
                <p>Aprovação imediata e desconto de {money(pixDiscount)}</p>
              </button>

              {methods.credit_card && (
                <button
                  type="button"
                  className={`payment-option-card ${
                    paymentMethod === "credit_card" ? "selected" : ""
                  }`}
                  onClick={() => setPaymentMethod("credit_card")}
                >
                  <div className="option-header">
                    <div className="option-icon-title">
                      <CreditCard size={22} className="orange-text" />
                      <strong>Cartão de Crédito</strong>
                    </div>
                    <span className="card-badge">Até 12x</span>
                  </div>
                  <p>Parcele em até 6x sem juros ou até 12x</p>
                </button>
              )}

              {methods.boleto && (
                <button
                  type="button"
                  className={`payment-option-card ${paymentMethod === "boleto" ? "selected" : ""}`}
                  onClick={() => setPaymentMethod("boleto")}
                >
                  <div className="option-header">
                    <div className="option-icon-title">
                      <Receipt size={22} className="orange-text" />
                      <strong>Boleto Bancário</strong>
                    </div>
                  </div>
                  <p>Compensação em até 1 a 3 dias úteis</p>
                </button>
              )}
            </div>

            {!methods.credit_card && (
              <p className="gateway-hint methods-note">
                <Info size={13} /> Pagamento via PIX — o valor cai direto na conta da loja. Cartão e
                boleto ficam disponíveis assim que uma processadora for conectada.
              </p>
            )}

            {paymentMethod === "credit_card" && (
              <div className="card-input-details">
                <label>
                  Número do Cartão
                  <div className="card-number-wrapper">
                    <input
                      required
                      value={cardNumber}
                      onChange={(e) => handleCardNumberChange(e.target.value)}
                      placeholder="0000 0000 0000 0000"
                      maxLength={19}
                    />
                    <span className="detected-brand">{detectCardBrand(cardNumber)}</span>
                  </div>
                </label>

                <label>
                  Nome Impresso no Cartão
                  <input
                    required
                    value={cardHolder}
                    onChange={(e) => setCardHolder(e.target.value.toUpperCase())}
                    placeholder="COMO NO CARTÃO"
                  />
                </label>

                <div className="grid-2-col">
                  <label>
                    Validade (MM/AA)
                    <input
                      required
                      value={cardExpiry}
                      onChange={(e) => handleExpiryChange(e.target.value)}
                      placeholder="MM/AA"
                      maxLength={5}
                    />
                  </label>
                  <label>
                    CVV (Cód. Segurança)
                    <input
                      required
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value.replace(/\D/g, "").slice(0, 4))}
                      placeholder="123"
                      maxLength={4}
                    />
                  </label>
                </div>

                <label>
                  Opções de Parcelamento
                  <select
                    value={installments}
                    onChange={(e) => setInstallments(Number(e.target.value))}
                  >
                    {[1, 2, 3, 4, 5, 6, 8, 10, 12].map((n) => {
                      const installmentVal = currentTotal / n;
                      const hasInterest = n > 6;
                      const finalInstallment = hasInterest
                        ? Math.round(installmentVal * 1.02)
                        : Math.round(installmentVal);
                      return (
                        <option value={n} key={n}>
                          {n}x de {money(finalInstallment)}{" "}
                          {hasInterest ? "(com taxa de juros)" : "(sem juros)"}
                        </option>
                      );
                    })}
                  </select>
                </label>
              </div>
            )}
          </fieldset>
        </div>

        {/* Right Column: Order summary & CTA */}
        <div className="checkout-summary-col">
          <div className="summary-card">
            <h3>Resumo da Compra</h3>
            <div className="checkout-items-list">
              {cart.map((item) => {
                const game = games.find((g) => g.id === item.gameId);
                if (!game) return null;
                return (
                  <div className="checkout-item-row" key={`${item.gameId}-${item.platform}`}>
                    <div>
                      <strong>
                        {item.quantity}x {game.title}
                      </strong>
                      <span>{platformLabel(game, item.platform)}</span>
                    </div>
                    <span>{money(game.price * item.quantity)}</span>
                  </div>
                );
              })}
            </div>

            <div className="summary-math">
              <div>
                <span>Subtotal</span>
                <span>{money(subtotal)}</span>
              </div>
              {paymentMethod === "pix" && (
                <div className="green-text">
                  <span>Desconto PIX ({discountPercent}%)</span>
                  <span>- {money(pixDiscount)}</span>
                </div>
              )}
              <div className="summary-final">
                <span>Total a Pagar</span>
                <strong>{money(currentTotal)}</strong>
              </div>
            </div>

            <label className="checkbox-label terms-check">
              <input type="checkbox" required defaultChecked />
              <span>
                Concordo com os termos de compra digital e políticas da Nexus Games.
              </span>
            </label>

            <Feedback error={error} />

            <Submit busy={busy}>
              {paymentMethod === "pix" ? (
                <>
                  <QrCode size={18} /> Gerar PIX ({money(currentTotal)})
                </>
              ) : paymentMethod === "credit_card" ? (
                <>
                  <CreditCard size={18} /> Pagar com Cartão ({money(currentTotal)})
                </>
              ) : (
                <>
                  <Receipt size={18} /> Gerar Boleto ({money(currentTotal)})
                </>
              )}
            </Submit>

            <div className="checkout-footer-guarantees">
              <span>
                <ShieldCheck size={13} /> Checkout 256-bit SSL Criptografado
              </span>
              <span>
                <Zap size={13} /> Liberação Imediata
              </span>
            </div>
          </div>
        </div>
      </form>
    </>
  );
}

function PaymentSettingsPanel({
  onClose,
  setDialog,
}: {
  onClose: () => void;
  setDialog: (d: DialogName) => void;
}) {
  const [settings, setSettings] = useState<PaymentSettings>(defaultPaymentSettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [savedMessage, setSavedMessage] = useState("");
  const [error, setError] = useState("");
  const [copiedHook, setCopiedHook] = useState("");
  const [showGateways, setShowGateways] = useState(false);
  const [testResults, setTestResults] = useState<
    { provider: string; label: string; ok: boolean; detail: string; live?: boolean }[] | null
  >(null);
  const [origin, setOrigin] = useState("https://seu-dominio.com.br");
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [token, setToken] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);

  const loadSettings = useCallback(() => {
    setLoading(true);
    fetch("/api/settings/payment")
      .then(async (res) => {
        if (res.status === 401) {
          setAuthed(false);
          return null;
        }
        setAuthed(true);
        return res.json();
      })
      .then((data) => {
        if (data?.settings) {
          const merged = { ...defaultPaymentSettings, ...data.settings };
          setSettings(merged);
          if (merged.asaasApiKey || merged.mercadoPagoAccessToken || merged.stripeSecretKey) {
            setShowGateways(true);
          }
        }
      })
      .catch((err) => console.error(err))
      .finally(() => setLoading(false));
  }, []);

  async function login(e: FormEvent) {
    e.preventDefault();
    setLoginBusy(true);
    setError("");
    try {
      const r = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Senha incorreta.");
      setAuthed(true);
      loadSettings();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Senha incorreta.");
    } finally {
      setLoginBusy(false);
    }
  }

  useEffect(() => {
    if (typeof window !== "undefined") setOrigin(window.location.origin);
    loadSettings();
  }, [loadSettings]);

  async function handleSave(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    setSavedMessage("");
    setError("");
    try {
      const resp = await fetch("/api/settings/payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || "Erro ao salvar configurações");
      setSavedMessage("Configurações salvas e já valendo no checkout.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro ao salvar.");
    } finally {
      setSaving(false);
    }
  }

  async function handleTest() {
    setTesting(true);
    setTestResults(null);
    setError("");
    try {
      const resp = await fetch("/api/settings/payment/test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      });
      const data = await resp.json();
      if (!resp.ok) throw new Error(data.error || "Falha no teste.");
      setTestResults(data.results);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Falha ao testar conexão.");
    } finally {
      setTesting(false);
    }
  }

  function copyHook(url: string, id: string) {
    navigator.clipboard.writeText(url);
    setCopiedHook(id);
    setTimeout(() => setCopiedHook(""), 2500);
  }

  const hasGateway = !!(
    settings.asaasApiKey ||
    settings.mercadoPagoAccessToken ||
    settings.stripeSecretKey
  );

  if (authed === false) {
    return (
      <div className="payment-settings-dialog">
        <span className="dialog-eyebrow">
          <LockKeyhole size={18} /> ÁREA RESTRITA
        </span>
        <h2 id="dialog-title">Configurações de Pagamento</h2>
        <p className="dialog-description">
          Aqui você define <strong>para qual chave PIX o dinheiro vai cair</strong>. Como essa área
          guarda dados sensíveis, ela é protegida por senha.
        </p>

        <div className="password-hint">
          <KeyRound size={18} />
          <div>
            <strong>Senha padrão: nexus-admin</strong>
            <p>
              Use essa senha para entrar agora. Antes de publicar o site, troque definindo a
              variável <code>ADMIN_TOKEN</code> no servidor.
            </p>
          </div>
          <button
            type="button"
            className="button button-secondary"
            onClick={() => setToken("nexus-admin")}
          >
            Preencher
          </button>
        </div>

        <form className="dialog-form" onSubmit={login}>
          <label>
            Senha do painel
            <input
              type="password"
              required
              autoFocus
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="nexus-admin"
            />
          </label>
          <Feedback error={error} />
          <button type="submit" className="button button-primary button-full" disabled={loginBusy}>
            {loginBusy ? <LoaderCircle size={16} className="spin" /> : <LockKeyhole size={16} />}
            Entrar
          </button>
        </form>
      </div>
    );
  }

  return (
    <div className="payment-settings-dialog">
      <span className="dialog-eyebrow">
        <Settings size={18} /> PAINEL DO LOJISTA
      </span>
      <h2 id="dialog-title">Como Você Vai Receber</h2>

      {loading ? (
        <div className="orders-loading">
          <LoaderCircle className="spin" size={24} /> Carregando configurações...
        </div>
      ) : (
        <form onSubmit={handleSave} className="settings-form">
          {/* PIX Direto em destaque */}
          <div className="settings-section highlight-section">
            <div className="recommended-badge">
              <CheckCircle2 size={13} /> FUNCIONANDO AGORA · SEM CRIAR CONTA
            </div>
            <h3>
              <QrCode size={18} className="orange-text" /> PIX Direto na Sua Conta
            </h3>
            <p className="gateway-hint">
              O cliente escaneia o QR Code e o dinheiro cai <strong>direto no seu banco</strong>,
              sem taxas e sem intermediário. Você só precisa conferir no app do banco e confirmar o
              pedido no painel.
            </p>

            <div className="pix-destination-box">
              <div className="destination-head">
                <Wallet size={16} className="orange-text" />
                <strong>Onde o dinheiro vai cair</strong>
              </div>

              <div className="grid-2-col">
                <label>
                  Tipo da Chave PIX
                  <select
                    value={settings.pixKeyType}
                    onChange={(e) =>
                      setSettings({
                        ...settings,
                        pixKeyType: e.target.value as "email" | "cpf" | "random",
                      })
                    }
                  >
                    <option value="email">E-mail</option>
                    <option value="cpf">CPF / CNPJ</option>
                    <option value="random">Chave Aleatória (EVP)</option>
                  </select>
                </label>
                <label>
                  Sua Chave PIX
                  <input
                    required
                    value={settings.pixKey}
                    onChange={(e) => setSettings({ ...settings, pixKey: e.target.value })}
                    placeholder="sua-chave@exemplo.com.br"
                  />
                </label>
              </div>

              <p className="destination-confirm">
                <CheckCircle2 size={13} className="green-text" /> Todo pagamento PIX desta loja vai
                para <strong>{settings.pixKey || "— defina sua chave acima —"}</strong>
              </p>
            </div>

            <div className="grid-2-col">
              <label>
                Nome do Recebedor (aparece no app do cliente)
                <input
                  value={settings.merchantName}
                  onChange={(e) => setSettings({ ...settings, merchantName: e.target.value })}
                  placeholder="SEU NOME OU LOJA"
                  maxLength={25}
                />
              </label>
              <label>
                Cidade
                <input
                  value={settings.merchantCity}
                  onChange={(e) => setSettings({ ...settings, merchantCity: e.target.value })}
                  placeholder="SAO PAULO"
                  maxLength={15}
                />
              </label>
            </div>

            <div className="grid-2-col">
              <label>
                Desconto no PIX (%)
                <input
                  type="number"
                  min={0}
                  max={30}
                  value={settings.pixDiscountPercent}
                  onChange={(e) =>
                    setSettings({ ...settings, pixDiscountPercent: Number(e.target.value) || 0 })
                  }
                />
              </label>
              <label>
                Parcelas Sem Juros (cartão)
                <input
                  type="number"
                  min={1}
                  max={12}
                  value={settings.freeInstallments}
                  onChange={(e) =>
                    setSettings({ ...settings, freeInstallments: Number(e.target.value) || 6 })
                  }
                />
              </label>
            </div>

            <button
              type="button"
              className="button button-secondary button-full"
              onClick={() => setDialog("admin-orders")}
            >
              <Package size={16} /> Abrir Painel de Pedidos para Confirmar Pagamentos
            </button>
          </div>

          {/* Gateways opcionais */}
          <div className="settings-section">
            <button
              type="button"
              className="collapse-head"
              onClick={() => setShowGateways(!showGateways)}
            >
              <span>
                <CreditCard size={18} className="orange-text" /> Gateway automática{" "}
                <em>(opcional)</em>
              </span>
              <ChevronRight
                size={16}
                style={{ transform: showGateways ? "rotate(90deg)" : "none" }}
              />
            </button>

            {!showGateways ? (
              <p className="gateway-hint">
                Conecte só se quiser <strong>baixa automática</strong> e pagamento com cartão. Sem
                isso, o PIX acima continua funcionando normalmente.
              </p>
            ) : (
              <>
                <div className="gateway-block recommended">
                  <div className="gateway-block-head">
                    <strong>Asaas</strong>
                    <span className="easy-tag">Abre com CPF · sem CNPJ</span>
                  </div>
                  <p className="gateway-hint">
                    Mais fácil para pessoa física: cadastro em minutos, PIX automático e conta
                    gratuita. Pegue a chave em <em>Integrações → API</em>.
                  </p>
                  <label>
                    Chave de API do Asaas
                    <input
                      type="password"
                      value={settings.asaasApiKey}
                      onChange={(e) => setSettings({ ...settings, asaasApiKey: e.target.value })}
                      placeholder="$aact_..."
                    />
                  </label>
                </div>

                <div className="gateway-block">
                  <div className="gateway-block-head">
                    <strong>Mercado Pago</strong>
                    <span>Se você já tiver conta</span>
                  </div>
                  <div className="grid-2-col">
                    <label>
                      Public Key
                      <input
                        value={settings.mercadoPagoPublicKey}
                        onChange={(e) =>
                          setSettings({ ...settings, mercadoPagoPublicKey: e.target.value })
                        }
                        placeholder="APP_USR-xxxx"
                      />
                    </label>
                    <label>
                      Access Token
                      <input
                        type="password"
                        value={settings.mercadoPagoAccessToken}
                        onChange={(e) =>
                          setSettings({ ...settings, mercadoPagoAccessToken: e.target.value })
                        }
                        placeholder="APP_USR-xxxx"
                      />
                    </label>
                  </div>
                </div>

                <div className="gateway-block">
                  <div className="gateway-block-head">
                    <strong>Stripe</strong>
                    <span>Cartão internacional</span>
                  </div>
                  <div className="grid-2-col">
                    <label>
                      Publishable Key
                      <input
                        value={settings.stripePublishableKey}
                        onChange={(e) =>
                          setSettings({ ...settings, stripePublishableKey: e.target.value })
                        }
                        placeholder="pk_live_..."
                      />
                    </label>
                    <label>
                      Secret Key
                      <input
                        type="password"
                        value={settings.stripeSecretKey}
                        onChange={(e) =>
                          setSettings({ ...settings, stripeSecretKey: e.target.value })
                        }
                        placeholder="sk_live_..."
                      />
                    </label>
                  </div>
                </div>

                <div className="radio-cards-grid">
                  <label
                    className={`radio-card ${settings.gatewayMode === "sandbox" ? "active" : ""}`}
                  >
                    <input
                      type="radio"
                      name="mode"
                      checked={settings.gatewayMode === "sandbox"}
                      onChange={() => setSettings({ ...settings, gatewayMode: "sandbox" })}
                    />
                    <div>
                      <strong>Modo Teste</strong>
                      <p>Credenciais de sandbox e botão de simular aprovação liberado.</p>
                    </div>
                  </label>
                  <label
                    className={`radio-card ${
                      settings.gatewayMode === "production" ? "active" : ""
                    }`}
                  >
                    <input
                      type="radio"
                      name="mode"
                      checked={settings.gatewayMode === "production"}
                      onChange={() => setSettings({ ...settings, gatewayMode: "production" })}
                    />
                    <div>
                      <strong>Modo Produção</strong>
                      <p>Dinheiro real. A simulação de aprovação fica bloqueada.</p>
                    </div>
                  </label>
                </div>

                <button
                  type="button"
                  className="button button-secondary button-full"
                  onClick={handleTest}
                  disabled={testing}
                >
                  {testing ? <LoaderCircle size={16} className="spin" /> : <Zap size={16} />}
                  Testar Conexão
                </button>

                {testResults && (
                  <div className="test-results">
                    {testResults.map((r) => (
                      <div key={r.provider} className={`test-row ${r.ok ? "ok" : "fail"}`}>
                        {r.ok ? <CheckCircle2 size={16} /> : <Info size={16} />}
                        <div>
                          <strong>{r.label}</strong>
                          <span>{r.detail}</span>
                        </div>
                        {r.live !== undefined && (
                          <span className={`live-pill ${r.live ? "live" : "test"}`}>
                            {r.live ? "PRODUÇÃO" : "TESTE"}
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {hasGateway && (
                  <>
                    <p className="gateway-hint">
                      Cadastre o webhook abaixo na sua gateway para o pedido ser aprovado sozinho:
                    </p>
                    <div className="webhook-row">
                      <div>
                        <small>MERCADO PAGO</small>
                        <code>{`${origin}/api/webhooks/mercadopago`}</code>
                      </div>
                      <button
                        type="button"
                        className="button button-secondary"
                        onClick={() => copyHook(`${origin}/api/webhooks/mercadopago`, "mp")}
                      >
                        {copiedHook === "mp" ? (
                          <Check size={14} className="green-text" />
                        ) : (
                          <Copy size={14} />
                        )}
                      </button>
                    </div>
                    <div className="webhook-row">
                      <div>
                        <small>STRIPE</small>
                        <code>{`${origin}/api/webhooks/stripe`}</code>
                      </div>
                      <button
                        type="button"
                        className="button button-secondary"
                        onClick={() => copyHook(`${origin}/api/webhooks/stripe`, "st")}
                      >
                        {copiedHook === "st" ? (
                          <Check size={14} className="green-text" />
                        ) : (
                          <Copy size={14} />
                        )}
                      </button>
                    </div>
                  </>
                )}
              </>
            )}
          </div>

          {savedMessage && (
            <p className="green-text" role="status">
              <CheckCircle2 size={16} /> {savedMessage}
            </p>
          )}
          <Feedback error={error} />

          <div className="settings-btn-row">
            <button type="submit" className="button button-primary" disabled={saving}>
              {saving ? <LoaderCircle size={16} className="spin" /> : <Check size={16} />} Salvar
            </button>
            <button type="button" className="button button-secondary" onClick={onClose}>
              Fechar
            </button>
          </div>
        </form>
      )}
    </div>
  );
}

function PublishGuidePanel({ onClose }: { onClose: () => void }) {
  const [copied, setCopied] = useState("");
  const [origin, setOrigin] = useState("");

  useEffect(() => {
    if (typeof window !== "undefined") setOrigin(window.location.origin);
  }, []);

  const envSample = `DATABASE_URL="postgresql://usuario:senha@host.neon.tech/db?sslmode=require"
NEXT_PUBLIC_SITE_URL="https://seudominio.com.br"

# Gateway (use as suas credenciais de produção)
MERCADO_PAGO_PUBLIC_KEY="APP_USR-..."
MERCADO_PAGO_ACCESS_TOKEN="APP_USR-..."
STRIPE_PUBLISHABLE_KEY="pk_live_..."
STRIPE_SECRET_KEY="sk_live_..."
PIX_CHAVE_PADRAO="sua-chave@pix.com.br"`;

  const copy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(""), 2500);
  };

  return (
    <div className="publish-guide-dialog">
      <span className="dialog-eyebrow">
        <Globe size={18} /> COLOCAR O SITE NO AR
      </span>
      <h2 id="dialog-title">Publicar a Loja em Domínio Próprio</h2>

      <div className="preview-live-box">
        <div>
          <small>SEU SITE JÁ ESTÁ RODANDO NESTE ENDEREÇO DE PRÉVIA</small>
          <code>{origin || "carregando..."}</code>
          <p>
            Esta prévia é temporária. Para um endereço fixo e domínio próprio, siga os 4 passos
            abaixo — leva cerca de 10 minutos.
          </p>
        </div>
      </div>

      <div className="deploy-steps-list">
        <div className="deploy-step-card">
          <div className="step-number">1</div>
          <div className="step-content">
            <h4>Crie o banco de dados PostgreSQL</h4>
            <p>
              Crie uma conta gratuita no <strong>Neon.tech</strong> ou <strong>Supabase</strong>,
              gere um banco e copie a connection string (ela começa com{" "}
              <code>postgresql://</code>).
            </p>
          </div>
        </div>

        <div className="deploy-step-card">
          <div className="step-number">2</div>
          <div className="step-content">
            <h4>Suba o código e publique na Vercel</h4>
            <p>
              Envie o projeto para um repositório no GitHub, acesse <strong>vercel.com</strong>,
              clique em <em>Add New → Project</em> e importe o repositório. A Vercel detecta o
              Next.js e faz o build sozinha.
            </p>
          </div>
        </div>

        <div className="deploy-step-card">
          <div className="step-number">3</div>
          <div className="step-content">
            <h4>Configure as variáveis de ambiente</h4>
            <p>
              Em <em>Settings → Environment Variables</em>, cole as variáveis abaixo com os seus
              dados reais:
            </p>
            <div className="env-box">
              <pre>{envSample}</pre>
              <button
                type="button"
                className="copy-env-btn button button-secondary"
                onClick={() => copy(envSample, "env")}
              >
                {copied === "env" ? (
                  <>
                    <Check size={14} className="green-text" /> Copiado
                  </>
                ) : (
                  <>
                    <Copy size={14} /> Copiar
                  </>
                )}
              </button>
            </div>
            <p className="gateway-hint">
              Depois do primeiro deploy, rode <code>npx drizzle-kit push</code> apontando para o
              banco de produção para criar as tabelas.
            </p>
          </div>
        </div>

        <div className="deploy-step-card">
          <div className="step-number">4</div>
          <div className="step-content">
            <h4>Conecte seu domínio e os webhooks</h4>
            <p>
              Em <em>Settings → Domains</em>, adicione seu domínio (o SSL é automático). Em seguida,
              cadastre as URLs de webhook na sua gateway usando o domínio final:
            </p>
            <div className="webhook-row compact">
              <code>https://seudominio.com.br/api/webhooks/mercadopago</code>
              <button
                type="button"
                className="button button-secondary"
                onClick={() => copy("https://seudominio.com.br/api/webhooks/mercadopago", "mp")}
              >
                {copied === "mp" ? <Check size={14} className="green-text" /> : <Copy size={14} />}
              </button>
            </div>
            <div className="webhook-row compact">
              <code>https://seudominio.com.br/api/webhooks/stripe</code>
              <button
                type="button"
                className="button button-secondary"
                onClick={() => copy("https://seudominio.com.br/api/webhooks/stripe", "st")}
              >
                {copied === "st" ? <Check size={14} className="green-text" /> : <Copy size={14} />}
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="notice">
        <Info size={19} />
        <p>
          <strong>Antes de vender de verdade:</strong> troque o modo da gateway para{" "}
          <em>Produção</em>, confirme que você tem autorização para revender as licenças e publique
          seus dados de CNPJ, trocas e reembolso para cumprir o Código de Defesa do Consumidor.
        </p>
      </div>

      <div className="publish-actions">
        <button className="button button-primary" onClick={onClose}>
          Entendi, vamos publicar <ArrowRight size={16} />
        </button>
      </div>
    </div>
  );
}

function Reservation({
  profile,
  saveProfile,
  onClose,
}: {
  profile: Profile;
  saveProfile: (profile: Profile) => void;
  onClose: () => void;
}) {
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [phone, setPhone] = useState(profile.phone || "");
  const [consent, setConsent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<{ code: string | null; message: string } | null>(null);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const data = await sendJson("/api/reservations", { name, email, phone, consent });
      setResult(data);
      saveProfile({ name: name.trim(), email: email.trim(), phone });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Tente novamente.");
    } finally {
      setBusy(false);
    }
  }

  if (result)
    return (
      <div className="success-state">
        <div className="success-icon">
          <CheckCircle2 size={43} />
        </div>
        <span className="dialog-eyebrow">VICE CITY ESTÁ CHAMANDO</span>
        <h2 id="dialog-title">Você está na lista prioritária!</h2>
        <p>{result.message}</p>
        {result.code && (
          <div className="confirmation-code">
            <small>SUA RESERVA DE INTERESSE · PS5</small>
            <strong>{result.code}</strong>
          </div>
        )}
        <p className="fine-print">
          Registro prioritário para PS5. Você receberá aviso no e-mail assim que a pré-venda oficial
          for liberada.
        </p>
        <button className="button button-primary button-full" onClick={onClose}>
          Continuar explorando a loja <ArrowRight size={17} />
        </button>
      </div>
    );

  return (
    <>
      <div className="reservation-art">
        <Image src="/images/gta-hero.webp" alt="Jason e Lucia em Vice City, GTA VI" fill sizes="500px" />
        <span className="preorder-tag">PRÉ-VENDA OFICIAL · PS5</span>
      </div>
      <span className="dialog-eyebrow">O MAIOR LANÇAMENTO DA DÉCADA</span>
      <h2 id="dialog-title">Grand Theft Auto VI</h2>
      <div className="reservation-meta">
        <span>
          <PlatformIcon platform="PS5" /> PlayStation 5 & PS5 Pro
        </span>
        <span>19 NOV 2026</span>
      </div>
      <p className="dialog-description">
        Garanta sua prioridade na fila de pré-venda de GTA VI no PlayStation 5.{" "}
        <strong>Sem cobrança antecipada.</strong>
      </p>
      <div className="reservation-price">
        <span>Preço estimado da edição</span>
        <strong>A confirmar pela Rockstar</strong>
      </div>
      <form className="dialog-form" onSubmit={submit}>
        <label>
          Seu nome
          <input
            required
            minLength={2}
            maxLength={100}
            autoComplete="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Seu nome"
          />
        </label>
        <label>
          Seu e-mail
          <input
            required
            type="email"
            maxLength={254}
            autoComplete="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="voce@email.com"
          />
        </label>
        <label>
          WhatsApp para aviso de lançamento (opcional)
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="(11) 99999-9999"
          />
        </label>
        <label className="checkbox-label">
          <input
            type="checkbox"
            checked={consent}
            onChange={(e) => setConsent(e.target.checked)}
            required
          />
          <span>
            Quero receber alertas de abertura da pré-venda e materiais exclusivos de GTA VI.
          </span>
        </label>
        <Feedback error={error} />
        <Submit busy={busy}>
          Garantir Minha Vaga na Pré-Venda <ArrowRight size={17} />
        </Submit>
      </form>
      <p className="fine-print center">
        Data anunciada pela{" "}
        <a href="https://www.rockstargames.com/VI" target="_blank" rel="noreferrer">
          Rockstar Games
        </a>
        . Classificação indicativa 18 anos.
      </p>
    </>
  );
}

function ProfilePanel({
  profile,
  saveProfile,
  setDialog,
}: {
  profile: Profile;
  saveProfile: (profile: Profile) => void;
  setDialog: (d: DialogName) => void;
}) {
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [cpf, setCpf] = useState(profile.cpf || "");
  const [saved, setSaved] = useState(false);
  const [orders, setOrders] = useState<SavedOrder[]>([]);
  const [busy, setBusy] = useState(true);
  const [error, setError] = useState("");
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    let active = true;
    fetch("/api/orders")
      .then(async (response) => {
        const data = await response.json();
        if (!response.ok) throw new Error(data.error);
        if (active) {
          setOrders(data.orders);
          setError("");
        }
      })
      .catch(() => {
        if (active) setError("Não foi possível carregar seus pedidos.");
      })
      .finally(() => {
        if (active) setBusy(false);
      });
    return () => {
      active = false;
    };
  }, [attempt]);

  return (
    <>
      <span className="dialog-eyebrow">
        <Gamepad2 size={18} /> MEU PERFIL & HISTÓRICO
      </span>
      <h2 id="dialog-title">Minha Conta Nexus</h2>
      <p className="dialog-description">
        Seus dados cadastrados e pedidos realizados com entrega de jogos e códigos digitais.
      </p>

      <form
        className="dialog-form"
        onSubmit={(event) => {
          event.preventDefault();
          saveProfile({ name: name.trim(), email: email.trim(), cpf });
          setSaved(true);
        }}
      >
        <div className="grid-2-col">
          <label>
            Seu nome
            <input
              required
              minLength={2}
              maxLength={100}
              autoComplete="name"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                setSaved(false);
              }}
              placeholder="Seu nome"
            />
          </label>
          <label>
            Seu e-mail
            <input
              required
              type="email"
              maxLength={254}
              autoComplete="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setSaved(false);
              }}
              placeholder="voce@email.com"
            />
          </label>
        </div>

        <button className="button button-secondary button-full" type="submit">
          {saved ? (
            <>
              <Check size={17} /> Dados Salvos
            </>
          ) : (
            "Salvar Meus Dados"
          )}
        </button>
      </form>

      <div className="admin-quick-actions">
        <button
          className="admin-link-btn"
          onClick={() => setDialog("payment-settings")}
        >
          <Settings size={15} /> Configurar Formas de Pagamento & Gateway
        </button>
        <button
          className="admin-link-btn"
          onClick={() => setDialog("publish-guide")}
        >
          <Globe size={15} /> Ver Guia de Publicação do Site (Deploy)
        </button>
      </div>

      <div className="orders-heading">
        <Package size={20} />
        <h3>Meus Pedidos Realizados</h3>
      </div>
      {busy ? (
        <div className="orders-loading">
          <LoaderCircle className="spin" size={24} /> Carregando pedidos...
        </div>
      ) : error ? (
        <div className="orders-empty">
          <p role="alert">{error}</p>
          <button
            className="text-button"
            onClick={() => {
              setBusy(true);
              setAttempt((v) => v + 1);
            }}
          >
            Tentar novamente
          </button>
        </div>
      ) : !orders.length ? (
        <div className="orders-empty">
          <ShoppingBag size={30} />
          <p>Você ainda não realizou nenhum pedido. Aproveite nossas ofertas!</p>
        </div>
      ) : (
        <div className="saved-orders">
          {orders.map((order) => (
            <article className="saved-order" key={order.code}>
              <div className="order-head">
                <strong>{order.code}</strong>
                <span>{new Date(order.createdAt).toLocaleDateString("pt-BR")}</span>
              </div>
              <ul className="order-items-list">
                {order.items.map((item, index) => (
                  <li key={index}>
                    {item.quantity}× {item.title} <small>· {item.platform}</small>
                  </li>
                ))}
              </ul>
              <footer>
                <div className="order-method-badge">
                  {order.paymentMethod === "pix"
                    ? "PIX (5% OFF)"
                    : order.paymentMethod === "credit_card"
                    ? `Cartão ${order.cardBrand || ""} (${order.installments || 1}x)`
                    : "Boleto"}
                  <span className="order-status-tag">{order.paymentStatus}</span>
                </div>
                <strong>{money(order.total)}</strong>
              </footer>
            </article>
          ))}
        </div>
      )}
    </>
  );
}

function Trailer() {
  return (
    <>
      <span className="dialog-eyebrow">ROCKSTAR GAMES APRESENTA</span>
      <h2 id="dialog-title">Grand Theft Auto VI — Trailer Oficial</h2>
      <div className="video-container">
        <iframe
          src="https://www.youtube-nocookie.com/embed/VQRLujxTm3c?rel=0"
          title="Grand Theft Auto VI Trailer 2 — Rockstar Games"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
          allowFullScreen
          referrerPolicy="strict-origin-when-cross-origin"
        />
      </div>
      <p className="fine-print">
        Assista no canal oficial da Rockstar:{" "}
        <a href="https://www.youtube.com/watch?v=VQRLujxTm3c" target="_blank" rel="noreferrer">
          Ver no YouTube <ChevronRight size={12} />
        </a>
      </p>
    </>
  );
}

function Information({ kind }: { kind: "help" | "privacy" | "about" }) {
  if (kind === "privacy")
    return (
      <>
        <span className="dialog-eyebrow">
          <LockKeyhole size={17} /> SEGURANÇA E PRIVACIDADE
        </span>
        <h2 id="dialog-title">Privacidade e Proteção de Dados</h2>
        <div className="information-copy">
          <p>
            Na Nexus Games, levamos a segurança de suas compras muito a sério. Todos os dados são
            transmitidos sob criptografia SSL de 256 bits.
          </p>
          <h3>Como tratamos seus pagamentos?</h3>
          <p>
            Os pagamentos por cartão e PIX são processados diretamente por gateways financeiros
            certificados (como Mercado Pago e Stripe). Não armazenamos o código de segurança (CVV)
            dos cartões.
          </p>
          <h3>Garantia e Envio Digital</h3>
          <p>
            Os jogos e licenças digitais adquiridos são disponibilizados para ativação imediata em sua
            conta PlayStation Network ou Xbox Live.
          </p>
        </div>
      </>
    );

  if (kind === "about")
    return (
      <>
        <span className="dialog-eyebrow">
          <Gamepad2 size={18} /> QUEM SOMOS
        </span>
        <h2 id="dialog-title">Sobre a Nexus Games</h2>
        <div className="information-copy">
          <p>
            A Nexus Games é a loja de games favorita do Brasil, trazendo os melhores títulos para
            PlayStation 5, PlayStation 4, PlayStation 3 e Xbox com os preços mais baratos do mercado.
          </p>
          <p>
            Trabalhamos com envio digital imediato, suporte técnico especializado e facilidade no
            pagamento com desconto exclusivo no PIX e parcelamento no cartão.
          </p>
        </div>
      </>
    );

  return (
    <>
      <span className="dialog-eyebrow">
        <ShieldCheck size={18} /> SUPORTE AO JOGADOR
      </span>
      <h2 id="dialog-title">Central de Ajuda & Dúvidas Frequentes</h2>
      <p className="dialog-description">Encontre respostas rápidas para suas principais dúvidas.</p>
      <div className="faq-list">
        <details open>
          <summary>
            Como recebo meus jogos após a compra?
            <Plus size={17} />
          </summary>
          <p>
            Assim que seu pagamento via PIX ou Cartão for aprovado, seu código de ativação digital e
            instruções de resgate são enviados imediatamente para o seu e-mail cadastrado e ficam
            disponíveis na aba “Meus Pedidos”.
          </p>
        </details>
        <details>
          <summary>
            Quais são as formas de pagamento aceitas?
            <Plus size={17} />
          </summary>
          <p>
            Aceitamos <strong>PIX com 5% de desconto imediato</strong>, Cartão de Crédito (Visa,
            Mastercard, Elo, Hipercard, Amex) em até 6x sem juros (ou até 12x), e Boleto Bancário.
          </p>
        </details>
        <details>
          <summary>
            Como funciona a pré-venda do GTA VI para PS5?
            <Plus size={17} />
          </summary>
          <p>
            A reserva garante sua prioridade na fila de entrega do lançamento mais aguardado.
            Informaremos por e-mail e WhatsApp assim que o preload for liberado pela Rockstar Games.
          </p>
        </details>
        <details>
          <summary>
            Os jogos funcionam no meu console?
            <Plus size={17} />
          </summary>
          <p>
            Sim! Cada jogo possui especificação clara de compatibilidade (PS3, PS4, PS5 e Xbox).
            Basta selecionar o console desejado no momento de adicionar ao carrinho.
          </p>
        </details>
      </div>
    </>
  );
}

export function ProductDetail({
  game,
  initialPlatform,
  favorite,
  onFavorite,
  onAdd,
  onClose,
}: {
  game: Game;
  initialPlatform: Platform;
  favorite: boolean;
  onFavorite: () => void;
  onAdd: (game: Game, platform: Platform) => void;
  onClose: () => void;
}) {
  const [platform, setPlatform] = useState<Platform>(initialPlatform);
  const pixValue = pixPrice(game.price);

  return (
    <Dialog onClose={onClose} wide>
      <div className="product-detail">
        <div className="detail-art">
          <Image src={game.image} width={600} height={750} alt={`Capa de ${game.title}`} />
          <span className="detail-discount">-{discount(game)}%</span>
          {game.tag && <span className="detail-tag-badge">{game.tag}</span>}
        </div>
        <div className="detail-copy">
          <span className="dialog-eyebrow">OFERTA ESPECIAL</span>
          <h2 id="dialog-title">{game.title}</h2>
          <p className="detail-subtitle">{game.subtitle}</p>
          <div className="detail-rating">
            <Star size={15} fill="currentColor" />
            <strong>{game.rating}</strong>
            <span>Avaliação Excelente</span>
            <span>· Ano {game.year}</span>
          </div>
          <p className="detail-description">{game.description}</p>
          <span className="detail-genre">{game.genre}</span>

          <label className="platform-select-label">
            Selecione a Versão do Console
            <select
              value={platform}
              onChange={(event) => setPlatform(event.target.value as Platform)}
            >
              {game.platforms.map((p) => (
                <option value={p} key={p}>
                  {platformLabel(game, p)}
                </option>
              ))}
            </select>
          </label>

          <div className="detail-price-box">
            <div className="detail-price-top">
              <del>{money(game.originalPrice)}</del>
              <strong>{money(game.price)}</strong>
              <span className="pix-extra-badge">
                <Zap size={13} /> {money(pixValue)} no PIX (5% OFF)
              </span>
            </div>
            <span className="detail-installments-text">
              ou em até 6x de {money(Math.round(game.price / 6))} sem juros no cartão
            </span>
          </div>

          <div className="detail-actions">
            <button
              className="button button-primary button-full"
              onClick={() => {
                onAdd(game, platform);
                onClose();
              }}
            >
              <ShoppingCart size={18} /> Adicionar ao Carrinho <ArrowRight size={17} />
            </button>
            <button
              className={`button button-secondary button-full detail-favorite ${
                favorite ? "is-favorite" : ""
              }`}
              onClick={onFavorite}
            >
              <Heart size={17} fill={favorite ? "currentColor" : "none"} />
              {favorite ? "Salvo nos Favoritos" : "Adicionar aos Favoritos"}
            </button>
          </div>

          <div className="detail-perks">
            <span>
              <Zap size={14} className="orange-text" /> Envio Digital Imediato
            </span>
            <span>
              <ShieldCheck size={14} className="green-text" /> Garantia Vitalícia
            </span>
          </div>
        </div>
      </div>
    </Dialog>
  );
}
