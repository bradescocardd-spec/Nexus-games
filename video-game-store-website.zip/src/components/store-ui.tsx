"use client";

import { useEffect, useRef, type ReactNode } from "react";
import { X } from "lucide-react";
import type { Platform } from "@/lib/catalog";

export function Brand({ onClick }: { onClick?: () => void }) {
  return <button className="brand" onClick={onClick} aria-label="Nexus Games — início">
    <svg className="brand-mark" viewBox="0 0 40 40" fill="none" aria-hidden="true"><path d="M5 31V9h8l14 17V9h8v22h-8L13 14v17H5Z" fill="currentColor"/><path d="m5 9 8-5 22 27-8 5L5 9Z" fill="currentColor" opacity=".45"/></svg>
    <span className="brand-word">NEXUS<span>GAMES</span></span>
  </button>;
}

export function PlatformIcon({ platform, size = 19 }: { platform: Platform | "playstation"; size?: number }) {
  if (platform === "Xbox") return <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><circle cx="12" cy="12" r="10" fill="none" stroke="currentColor" strokeWidth="1.6"/><path d="M5 5c3-1 5 1 7 3 2-2 4-4 7-3-2 0-4 3-5.5 5 2 3 4.5 6 5 10-2-3-4.5-6-6.5-8-2 2-4.5 5-6.5 8 .5-4 3-7 5-10C9 8 7 5 5 5Z"/></svg>;
  return <svg width={size + 3} height={size} viewBox="0 0 28 24" fill="currentColor" aria-hidden="true"><path d="M10 2v18l4 1.3V6.1c0-.7.5-1 1-.8.9.3 1 1.2 1 2.2v6.2c3.5 1.7 6.2.1 6.2-4.1 0-4.4-3.3-5.9-7.4-7.1L10 2Z"/><path d="m8.7 15-5.4 1.9c-2.9 1-3.4 2.5-1 3.3 2.3.8 5.7 1 8 .2v-2.5l-3 .9c-1.3.4-3 .4-3.6.1-.7-.3-.3-.7.7-1l4.3-1.5V15Zm7.1 3.4 5.3-1.8c1.3-.4 3-.4 3.6-.1.7.3.3.7-.7 1l-8.2 2.8v2.5l11-3.8c2.9-1 3.4-2.5 1-3.3-2.3-.8-5.7-1-8-.2l-4 1.4v1.5Z"/></svg>;
}

export function Dialog({ children, onClose, drawer = false, wide = false }: { children: ReactNode; onClose: () => void; drawer?: boolean; wide?: boolean }) {
  const panel = useRef<HTMLElement>(null);
  useEffect(() => {
    const prior = document.activeElement as HTMLElement | null;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panel.current?.focus();
    const keyHandler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab" && panel.current) {
        const elements = Array.from(panel.current.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input:not([disabled]), select, textarea, [tabindex="0"]')).filter((el) => el.getClientRects().length > 0);
        const first = elements[0]; const last = elements[elements.length - 1];
        if (!first) { event.preventDefault(); return; }
        if (event.shiftKey && (document.activeElement === first || document.activeElement === panel.current)) { event.preventDefault(); last.focus(); }
        else if (!event.shiftKey && (document.activeElement === last || document.activeElement === panel.current)) { event.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener("keydown", keyHandler);
    return () => { document.body.style.overflow = overflow; document.removeEventListener("keydown", keyHandler); prior?.focus(); };
  }, [onClose]);
  return <div className={`modal-overlay ${drawer ? "drawer-overlay" : ""}`} onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}>
    <section className={`dialog ${drawer ? "drawer" : ""} ${wide ? "dialog-wide" : ""}`} ref={panel} tabIndex={-1} role="dialog" aria-modal="true" aria-labelledby="dialog-title">
      <button className="dialog-close icon-button" onClick={onClose} aria-label="Fechar janela"><X size={21}/></button>
      {children}
    </section>
  </div>;
}
