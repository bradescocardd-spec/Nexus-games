"use client";

import Image from "next/image";
import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import {
  ArrowDown,
  ArrowRight,
  BadgePercent,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CreditCard,
  DollarSign,
  Flame,
  Gamepad2,
  Globe,
  Headset,
  Heart,
  LayoutGrid,
  LoaderCircle,
  LockKeyhole,
  Mail,
  Menu,
  MessageCircle,
  Package,
  Play,
  QrCode,
  Search,
  Settings,
  ShieldCheck,
  ShoppingBag,
  ShoppingCart,
  SlidersHorizontal,
  Sparkles,
  Star,
  Tag,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import { discount, games, money, pixPrice, platformLabel, type Game, type Platform } from "@/lib/catalog";
import { sendJson, type CartItem, type DialogName, type Profile } from "@/lib/store-types";
import { Brand, PlatformIcon } from "./store-ui";
import { ProductDetail, StoreDialogs } from "./store-dialogs";

type Filter = "all" | Platform;
const filters: { id: Filter; label: string }[] = [
  { id: "all", label: `Todos os Jogos (${games.length})` },
  { id: "PS5", label: "PlayStation 5" },
  { id: "PS4", label: "PlayStation 4" },
  { id: "PS3", label: "PlayStation 3" },
  { id: "Xbox", label: "Xbox Series & One" },
];

const slides = [
  {
    image: "/images/gta-hero.webp",
    tag: "PRÉ-VENDA OFICIAL · PS5",
    title: (
      <>
        Grand Theft Auto VI<br />
        Chegando ao PS5<span className="orange-text">.</span>
      </>
    ),
    description:
      "Vice City está mais viva do que nunca. Garanta sua cópia na pré-venda oficial para PlayStation 5 por R$ 389,90 — ou R$ 370,41 no PIX.",
    cta: "Comprar Pré-Venda · R$ 389,90",
    gameId: "gta6",
  },
  {
    image: "/images/astro.webp",
    tag: "GOTY 2024 · SUPER OFERTA",
    title: (
      <>
        Astro Bot no PS5<br />
        Por apenas R$ 79,90<span className="orange-text">.</span>
      </>
    ),
    description:
      "O aclamado jogo do ano com 73% de desconto. Aproveite os gráficos da nova geração e toda a magia do DualSense.",
    cta: "Comprar Astro Bot",
    gameId: "astro",
  },
  {
    image: "/images/fc26.webp",
    tag: "FUTEBOL EM ALTA",
    title: (
      <>
        EA SPORTS FC 26<br />
        De R$ 349 por R$ 89,90<span className="orange-text">.</span>
      </>
    ),
    description:
      "Monte seu Ultimate Team e dispute os maiores campeonatos mundiais no PS5, PS4 e Xbox com desconto recorde.",
    cta: "Ver Oferta de FC 26",
    gameId: "fc26",
  },
];

export default function Storefront() {
  const [filter, setFilter] = useState<Filter>("all");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState("popular");
  const [offerOnly, setOfferOnly] = useState(false);
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [visibleCount, setVisibleCount] = useState(15);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [profile, setProfile] = useState<Profile>({ name: "", email: "" });
  const [hydrated, setHydrated] = useState(false);
  const [dialog, setDialog] = useState<DialogName>(null);
  const [detailGame, setDetailGame] = useState<Game | null>(null);
  const [toast, setToast] = useState("");
  const [slide, setSlide] = useState(0);
  const [psMenu, setPsMenu] = useState(false);
  const [mobileMenu, setMobileMenu] = useState(false);
  const [newsletterEmail, setNewsletterEmail] = useState("");
  const [newsletterBusy, setNewsletterBusy] = useState(false);
  const [newsletterStatus, setNewsletterStatus] = useState<{ success: boolean; message: string } | null>(
    null
  );
  const searchRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);
  const closeDialog = useCallback(() => setDialog(null), []);
  const closeDetail = useCallback(() => setDetailGame(null), []);

  useEffect(() => {
    try {
      const storedCart = JSON.parse(localStorage.getItem("nexus_cart") || "[]");
      if (Array.isArray(storedCart)) {
        setCart(
          storedCart.filter(
            (item: CartItem) =>
              item &&
              games.some((game) => game.id === item.gameId && game.platforms.includes(item.platform)) &&
              Number.isInteger(item.quantity) &&
              item.quantity > 0 &&
              item.quantity <= 10
          )
        );
      }
      const storedFavorites = JSON.parse(localStorage.getItem("nexus_favorites") || "[]");
      if (Array.isArray(storedFavorites)) {
        setFavorites(storedFavorites.filter((id) => games.some((game) => game.id === id)));
      }
      const storedProfile = JSON.parse(localStorage.getItem("nexus_profile") || "null");
      if (
        storedProfile &&
        typeof storedProfile.name === "string" &&
        typeof storedProfile.email === "string"
      ) {
        setProfile(storedProfile);
      }
    } catch {
      /* local storage safe */
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) {
      try {
        localStorage.setItem("nexus_cart", JSON.stringify(cart));
        localStorage.setItem("nexus_favorites", JSON.stringify(favorites));
        localStorage.setItem("nexus_profile", JSON.stringify(profile));
      } catch {
        /* storage safe */
      }
    }
  }, [cart, favorites, profile, hydrated]);

  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(""), 4500);
    return () => clearTimeout(timer);
  }, [toast]);

  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (
        event.key === "/" &&
        !["INPUT", "TEXTAREA", "SELECT"].includes((event.target as HTMLElement).tagName) &&
        !dialog &&
        !detailGame
      ) {
        event.preventDefault();
        searchRef.current?.focus();
      }
      if (event.key === "Escape") {
        setPsMenu(false);
        setMobileMenu(false);
      }
    };
    const click = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setPsMenu(false);
      }
    };
    document.addEventListener("keydown", key);
    document.addEventListener("click", click);
    return () => {
      document.removeEventListener("keydown", key);
      document.removeEventListener("click", click);
    };
  }, [dialog, detailGame]);

  const scrollCatalog = () =>
    document.getElementById("catalogo")?.scrollIntoView({ behavior: "smooth", block: "start" });

  function chooseFilter(value: Filter) {
    setFilter(value);
    setQuery("");
    setOfferOnly(false);
    setFavoritesOnly(false);
    setVisibleCount(15);
    setPsMenu(false);
    setMobileMenu(false);
    scrollCatalog();
  }

  function resetCatalog() {
    setFilter("all");
    setQuery("");
    setOfferOnly(false);
    setFavoritesOnly(false);
    setVisibleCount(15);
  }

  function home() {
    resetCatalog();
    setMobileMenu(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function showOffers() {
    resetCatalog();
    setOfferOnly(true);
    setMobileMenu(false);
    scrollCatalog();
  }

  function showFavorites() {
    resetCatalog();
    setFavoritesOnly(true);
    scrollCatalog();
  }

  function openDialog(value: DialogName) {
    setDialog(value);
    setPsMenu(false);
    setMobileMenu(false);
  }

  function toggleFavorite(gameId: string) {
    setFavorites((current) =>
      current.includes(gameId) ? current.filter((id) => id !== gameId) : [...current, gameId]
    );
  }

  function addToCart(game: Game, platform: Platform) {
    if (
      cart.some(
        (item) => item.gameId === game.id && item.platform === platform && item.quantity >= 10
      )
    ) {
      setToast("Limite de 10 unidades por jogo e console atingido.");
      return;
    }
    setCart((current) => {
      const existing = current.find(
        (item) => item.gameId === game.id && item.platform === platform
      );
      return existing
        ? current.map((item) =>
            item === existing
              ? { ...item, quantity: Math.min(10, item.quantity + 1) }
              : item
          )
        : [...current, { gameId: game.id, platform, quantity: 1 }];
    });
    setToast(`${game.title} adicionado ao carrinho.`);
  }

  function updateQuantity(gameId: string, platform: Platform, quantity: number) {
    setCart((current) =>
      quantity <= 0
        ? current.filter((item) => item.gameId !== gameId || item.platform !== platform)
        : current.map((item) =>
            item.gameId === gameId && item.platform === platform
              ? { ...item, quantity: Math.min(quantity, 10) }
              : item
          )
    );
  }

  const filteredGames = useMemo(() => {
    const normalized = query
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase()
      .trim();

    const result = games.filter(
      (game) =>
        (filter === "all" || game.platforms.includes(filter)) &&
        (!offerOnly || discount(game) >= 60) &&
        (!favoritesOnly || favorites.includes(game.id)) &&
        (!normalized ||
          `${game.title} ${game.genre} ${game.subtitle} ${game.platforms.join(" ")}`
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .includes(normalized))
    );

    if (sort === "price-low") result.sort((a, b) => a.price - b.price);
    if (sort === "price-high") result.sort((a, b) => b.price - a.price);
    if (sort === "newest") result.sort((a, b) => b.year - a.year);
    if (sort === "discount") result.sort((a, b) => discount(b) - discount(a));
    return result;
  }, [query, filter, offerOnly, favoritesOnly, favorites, sort]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const activeSlide = slides[slide];

  async function subscribe(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setNewsletterBusy(true);
    setNewsletterStatus(null);
    try {
      const data = await sendJson("/api/newsletter", { email: newsletterEmail });
      setNewsletterStatus({ success: true, message: data.message });
      setNewsletterEmail("");
    } catch (error) {
      setNewsletterStatus({
        success: false,
        message: error instanceof Error ? error.message : "Não foi possível se inscrever.",
      });
    } finally {
      setNewsletterBusy(false);
    }
  }

  return (
    <>
      {/* Top Notification Bar */}
      <div className="announcement">
        <div className="page-width announcement-inner">
          <span>
            <Zap size={13} fill="currentColor" /> SUPER LIQUIDAÇÃO DE GAMES · JOGOS A PARTIR DE R$ 14,90
          </span>
          <div>
            <span>
              <QrCode size={13} /> 5% de Desconto Extra no PIX
            </span>
            <span>
              <CreditCard size={13} /> Até 6x Sem Juros no Cartão
            </span>
            <i />
            <button
              onClick={() => openDialog("payment-settings")}
              className="top-bar-action"
              title="Configurar Gateways de Pagamento"
            >
              <Settings size={12} /> Configurar Pagamento
            </button>
            <button
              onClick={() => openDialog("admin-orders")}
              className="top-bar-action"
              title="Painel de pedidos e confirmação de pagamentos"
            >
              <Package size={12} /> Meus Pedidos (Admin)
            </button>
            <button
              onClick={() => openDialog("publish-guide")}
              className="top-bar-action highlight"
              title="Guia de Publicação e Deploy"
            >
              <Globe size={12} /> Como Publicar o Site
            </button>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className="site-header">
        <div className="page-width main-header">
          <Brand onClick={home} />

          <nav className="desktop-nav" aria-label="Navegação principal">
            <button
              className={!offerOnly && !favoritesOnly && filter === "all" ? "nav-link active" : "nav-link"}
              onClick={home}
            >
              Início
            </button>

            <div className="nav-dropdown" ref={dropdownRef}>
              <button
                className={`nav-link ${filter.startsWith("PS") ? "active" : ""}`}
                onClick={() => setPsMenu(!psMenu)}
                aria-expanded={psMenu}
              >
                PlayStation <ChevronDown size={12} />
              </button>
              {psMenu && (
                <div className="dropdown-panel">
                  {(["PS5", "PS4", "PS3"] as Platform[]).map((platform) => (
                    <button key={platform} onClick={() => chooseFilter(platform)}>
                      <PlatformIcon platform={platform} />
                      <span>PlayStation {platform.slice(-1)} ({games.filter(g => g.platforms.includes(platform)).length} jogos)</span>
                      <ChevronRight size={14} />
                    </button>
                  ))}
                </div>
              )}
            </div>

            <button
              className={`nav-link ${filter === "Xbox" ? "active" : ""}`}
              onClick={() => chooseFilter("Xbox")}
            >
              Xbox Series / One ({games.filter(g => g.platforms.includes("Xbox")).length})
            </button>

            <button
              className={`nav-link offers-link ${offerOnly ? "active" : ""}`}
              onClick={showOffers}
            >
              <Flame size={14} /> Super Ofertas
            </button>

            <button
              className="nav-link preorder-link"
              onClick={() => {
                document.getElementById("pre-venda")?.scrollIntoView({ behavior: "smooth" });
              }}
            >
              GTA VI PS5 <span className="nav-dot" />
            </button>
          </nav>

          <form
            className="header-search"
            role="search"
            onSubmit={(event) => {
              event.preventDefault();
              scrollCatalog();
            }}
          >
            <button aria-label="Buscar jogos" type="submit">
              <Search size={17} />
            </button>
            <input
              ref={searchRef}
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setVisibleCount(15);
                setFilter("all");
                setOfferOnly(false);
                setFavoritesOnly(false);
              }}
              placeholder={`Buscar entre ${games.length} jogos (PS3, PS4, PS5, Xbox)...`}
              aria-label="Buscar jogos no catálogo"
            />
            <kbd>/</kbd>
            {query && (
              <button
                className="clear-search"
                type="button"
                onClick={() => setQuery("")}
                aria-label="Limpar busca"
              >
                <X size={13} />
              </button>
            )}
          </form>

          <div className="header-actions">
            <button
              className="icon-button account-button"
              onClick={() => openDialog("profile")}
              aria-label="Meu perfil e meus pedidos"
              title="Meu Perfil & Pedidos"
            >
              <UserRound size={21} />
            </button>

            <button
              className={`icon-button ${favoritesOnly ? "orange-text" : ""}`}
              onClick={showFavorites}
              aria-label={`Meus favoritos, ${favorites.length} jogos`}
              title="Favoritos"
            >
              <Heart size={21} />
              {favorites.length > 0 && <span className="mini-count">{favorites.length}</span>}
            </button>

            <span className="header-divider" />

            <button
              className="cart-header-button"
              onClick={() => openDialog("cart")}
              aria-label={`Abrir carrinho, ${cartCount} itens`}
            >
              <ShoppingBag size={21} />
              <span className="cart-count">{cartCount}</span>
            </button>

            <button
              className="icon-button mobile-menu-toggle"
              onClick={() => setMobileMenu(!mobileMenu)}
              aria-label={mobileMenu ? "Fechar menu" : "Abrir menu"}
              aria-expanded={mobileMenu}
            >
              {mobileMenu ? <X size={23} /> : <Menu size={23} />}
            </button>
          </div>
        </div>

        {mobileMenu && (
          <nav className="mobile-nav" aria-label="Navegação móvel">
            <button onClick={home}>Início</button>
            {filters.slice(1).map((item) => (
              <button onClick={() => chooseFilter(item.id)} key={item.id}>
                {item.label}
              </button>
            ))}
            <button onClick={showOffers}>Super Ofertas (Até 84% OFF)</button>
            <button onClick={() => openDialog("reserve")}>Pré-Venda GTA VI</button>
            <button onClick={() => openDialog("payment-settings")}>
              <Settings size={14} /> Configurar Pagamento
            </button>
            <button onClick={() => openDialog("admin-orders")}>
              <Package size={14} /> Painel de Pedidos
            </button>
            <button onClick={() => openDialog("publish-guide")}>
              <Globe size={14} /> Como Publicar o Site
            </button>
          </nav>
        )}
      </header>

      <main className="page-width main-content">
        {/* Hero Section */}
        <section className={`hero hero-slide-${slide}`} aria-label="Jogos em destaque">
          <div className="hero-art" key={activeSlide.image}>
            <Image
              src={activeSlide.image}
              alt="Destaque de Jogos"
              fill
              priority
              sizes="(max-width: 760px) 100vw, 85vw"
              quality={90}
            />
          </div>
          <div className="hero-shade" />

          <div className="hero-content">
            <span className="hero-tag">
              <span />
              {activeSlide.tag}
            </span>
            <h1>{activeSlide.title}</h1>
            <p>{activeSlide.description}</p>

            <div className="hero-meta">
              <span>
                <PlatformIcon platform="PS5" size={16} /> PlayStation 5 & Xbox
              </span>
              <i />
              {slide === 0 ? (
                <span>
                  Lançamento Mundial: <strong>19.11.2026</strong>
                </span>
              ) : (
                <span>
                  Entrega Digital: <strong>Imediata via E-mail / PIX</strong>
                </span>
              )}
            </div>

            <div className="hero-actions">
              <button
                className="button button-primary"
                onClick={() =>
                  setDetailGame(games.find((game) => game.id === activeSlide.gameId)!)
                }
              >
                {activeSlide.cta}
                <ArrowRight size={17} />
              </button>
              {slide === 0 && (
                <button className="button button-glass" onClick={() => openDialog("reserve")}>
                  Só avisar quando lançar
                </button>
              )}
            </div>
            {slide === 0 && (
              <span className="hero-fine-print">
                <ShieldCheck size={12} /> Cobrança só na confirmação · Lançamento 19.11.2026 ·{" "}
                <button className="hero-inline-link" onClick={() => openDialog("trailer")}>
                  ver trailer
                </button>
              </span>
            )}
          </div>

          {slide === 0 && (
            <div className="hero-game-brand">
              <Image
                src="/images/gta-logo.webp"
                alt="Grand Theft Auto VI"
                width={193}
                height={129}
              />
              <span>19 NOVEMBRO 2026</span>
            </div>
          )}

          <div className="hero-bottom">
            <div className="hero-dots" aria-label="Selecionar destaque">
              {slides.map((_, index) => (
                <button
                  key={index}
                  className={index === slide ? "selected" : ""}
                  onClick={() => setSlide(index)}
                  aria-label={`Ver destaque ${index + 1}`}
                  aria-current={index === slide ? "true" : undefined}
                />
              ))}
            </div>
            <div className="hero-pagination">
              <span>
                0{slide + 1}
                <i> / 03</i>
              </span>
              <button onClick={() => setSlide((slide + 2) % 3)} aria-label="Destaque anterior">
                <ChevronLeft size={16} />
              </button>
              <button onClick={() => setSlide((slide + 1) % 3)} aria-label="Próximo destaque">
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        </section>

        {/* Benefits bar */}
        <section className="benefits" aria-label="Benefícios da Loja">
          <div className="benefit">
            <span className="benefit-icon">
              <QrCode size={23} />
            </span>
            <div>
              <strong>PIX com 5% de Desconto</strong>
              <span>Aprovação instantânea</span>
            </div>
          </div>
          <div className="benefit">
            <span className="benefit-icon">
              <CreditCard size={23} />
            </span>
            <div>
              <strong>Até 6x Sem Juros</strong>
              <span>Ou em até 12x no cartão</span>
            </div>
          </div>
          <div className="benefit">
            <span className="benefit-icon">
              <BadgePercent size={23} />
            </span>
            <div>
              <strong>Preços Mais Baratos</strong>
              <span>Jogos a partir de R$ 14,90</span>
            </div>
          </div>
          <button className="benefit benefit-help" onClick={() => openDialog("payment-settings")}>
            <span className="benefit-icon">
              <Settings size={23} />
            </span>
            <div>
              <strong>Configurar Pagamento</strong>
              <span>Chaves PIX e Gateways <ArrowRight size={11} /></span>
            </div>
          </button>
        </section>

        {/* Catalog Section */}
        <section className="catalog-section" id="catalogo">
          <div className="section-heading">
            <div>
              <span className="eyebrow">
                <span /> CATÁLOGO COMPLETO · {games.length} JOGOS SELECIONADOS
              </span>
              <h2>
                {favoritesOnly
                  ? "Seus Jogos Favoritos"
                  : offerOnly
                  ? "Super Ofertas (Até 84% de Desconto)"
                  : query
                  ? "Resultados da Busca"
                  : "Todos os Jogos para PS3, PS4, PS5 e Xbox"}
              </h2>
              <p>
                {favoritesOnly
                  ? "Todos os títulos salvos na sua lista de desejos."
                  : offerOnly
                  ? "Seleção especial com os maiores cortes de preço da história dos games."
                  : "Encontre os lançamentos mais recentes e os clássicos mais marcantes com preços imbatíveis."}
              </p>
            </div>
            <button
              className="section-link"
              onClick={() => {
                resetCatalog();
                setVisibleCount(games.length);
              }}
            >
              Ver todos os {games.length} jogos <ArrowRight size={15} />
            </button>
          </div>

          <div className="catalog-controls">
            <div className="platform-filters" aria-label="Filtrar por console">
              {filters.map((item) => (
                <button
                  key={item.id}
                  className={`filter-button ${filter === item.id ? "selected" : ""} ${
                    item.id === "Xbox" ? "xbox-filter" : ""
                  }`}
                  onClick={() => {
                    setFilter(item.id);
                    setVisibleCount(15);
                  }}
                  aria-pressed={filter === item.id}
                >
                  {item.id === "all" ? (
                    <LayoutGrid size={15} />
                  ) : (
                    <PlatformIcon platform={item.id} size={16} />
                  )}
                  {item.label}
                </button>
              ))}
            </div>

            <label className="sort-control">
              <SlidersHorizontal size={14} />
              <select
                aria-label="Ordenar jogos"
                value={sort}
                onChange={(event) => setSort(event.target.value)}
              >
                <option value="popular">Mais Populares</option>
                <option value="discount">Maior Desconto (%)</option>
                <option value="price-low">Menor Preço (R$)</option>
                <option value="price-high">Maior Preço (R$)</option>
                <option value="newest">Lançamentos Recentes</option>
              </select>
              <ChevronDown size={12} />
            </label>
          </div>

          {(query || offerOnly || favoritesOnly || filter !== "all") && (
            <div className="results-info">
              <span>
                {filteredGames.length}{" "}
                {filteredGames.length === 1 ? "jogo encontrado" : "jogos encontrados"}
                {query && (
                  <>
                    {" "}
                    para <strong>“{query}”</strong>
                  </>
                )}
              </span>
              <button onClick={resetCatalog}>
                Limpar filtros <X size={12} />
              </button>
            </div>
          )}

          {filteredGames.length ? (
            <>
              <div className="games-grid">
                {filteredGames.slice(0, visibleCount).map((game) => (
                  <GameCard
                    key={game.id}
                    game={game}
                    platform={
                      filter !== "all" && game.platforms.includes(filter)
                        ? filter
                        : game.platforms[0]
                    }
                    favorite={favorites.includes(game.id)}
                    onFavorite={() => toggleFavorite(game.id)}
                    onDetails={() => setDetailGame(game)}
                    onAdd={addToCart}
                  />
                ))}
              </div>

              {visibleCount < filteredGames.length && (
                <div className="load-more-wrap">
                  <button
                    className="button button-secondary load-more"
                    onClick={() => setVisibleCount((count) => count + 15)}
                  >
                    Carregar Mais Jogos ({filteredGames.length - visibleCount} restantes){" "}
                    <ArrowDown size={15} />
                  </button>
                  <span>
                    Mostrando {Math.min(visibleCount, filteredGames.length)} de{" "}
                    {filteredGames.length} jogos
                  </span>
                </div>
              )}
            </>
          ) : (
            <div className="catalog-empty">
              <Search size={38} />
              <h3>Nenhum jogo encontrado com esses critérios.</h3>
              <p>Tente buscar por outro nome ou selecione outro console.</p>
              <button className="button button-primary" onClick={resetCatalog}>
                Ver Todos os {games.length} Jogos <ArrowRight size={17} />
              </button>
            </div>
          )}
        </section>

        {/* Promo banners */}
        <section className="promo-grid" aria-label="Seleções especiais">
          <article className="promo-card classics-promo">
            <Image src="/images/ragnarok.webp" alt="God of War Ragnarök" fill sizes="50vw" />
            <div className="promo-shade" />
            <div className="promo-copy">
              <span className="eyebrow">GRANDES JOGOS COM ATÉ 84% OFF</span>
              <h3>
                Os Melhores Preços<br />
                do Mercado Gamer.
              </h3>
              <p>Clássicos e lançamentos com PIX e parcelamento facilitado.</p>
              <button className="promo-link" onClick={showOffers}>
                Aproveitar Super Ofertas <ArrowRight size={16} />
              </button>
            </div>
            <span className="promo-decoration">
              <BadgePercent size={24} />
            </span>
          </article>

          <article className="promo-card gta-promo" id="pre-venda">
            <Image src="/images/gta-poster.webp" alt="Arte oficial de GTA VI" fill sizes="50vw" />
            <div className="promo-shade" />
            <div className="promo-copy">
              <span className="eyebrow">PRÉ-VENDA OFICIAL · PLAYSTATION 5</span>
              <h3>
                Grand Theft Auto VI<br />
                por R$ 389,90.
              </h3>
              <p>19 de Novembro de 2026 · 12x de R$ 32,49 ou R$ 370,41 no PIX.</p>
              <button
                className="promo-link"
                onClick={() => setDetailGame(games.find((g) => g.id === "gta6")!)}
              >
                Comprar Pré-Venda PS5 <ArrowRight size={16} />
              </button>
            </div>
            <span className="promo-18">18</span>
          </article>
        </section>

        {/* Console Hub */}
        <section className="platform-section" id="plataformas">
          <div className="section-heading">
            <div>
              <span className="eyebrow">
                <span /> ESCOLHA SEU CONSOLE
              </span>
              <h2>Navegue por Plataforma</h2>
            </div>
            <span className="platform-heading-note">
              {games.length} jogos com compatibilidade e entrega digital garantida.
            </span>
          </div>

          <div className="console-grid">
            {(
              [
                { platform: "PS5", image: "astro", label: "A nova geração completa." },
                { platform: "PS4", image: "ragnarok", label: "Centenas de horas de aventura." },
                { platform: "PS3", image: "gtav", label: "Os maiores clássicos do videogame." },
                { platform: "Xbox", image: "forza5", label: "Xbox Series X|S & Xbox One." },
              ] as { platform: Platform; image: string; label: string }[]
            ).map((item) => (
              <button
                className={`console-card console-${item.platform.toLowerCase()}`}
                key={item.platform}
                onClick={() => chooseFilter(item.platform)}
              >
                <Image src={`/images/${item.image}.webp`} alt="" fill sizes="25vw" />
                <div className="console-shade" />
                <div className="console-card-copy">
                  <PlatformIcon platform={item.platform} size={21} />
                  <h3>{item.platform}</h3>
                  <p>{item.label}</p>
                  <span>
                    Ver jogos ({games.filter((g) => g.platforms.includes(item.platform)).length}){" "}
                    <ArrowRight size={13} />
                  </span>
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* Newsletter */}
        <section className="newsletter">
          <div className="newsletter-title">
            <span className="newsletter-icon">
              <Mail size={28} />
            </span>
            <div>
              <span className="eyebrow">NOTIFICAÇÕES DE PROMOÇÃO & LANÇAMENTO</span>
              <h2>Receba Cupons e Alertas de Pré-Venda</h2>
              <p>Cadastre seu e-mail para receber cupons exclusivos e aviso de abertura de GTA VI.</p>
            </div>
          </div>

          <div className="newsletter-form-wrap">
            <form onSubmit={subscribe}>
              <label className="newsletter-input">
                <Mail size={17} />
                <input
                  aria-label="Seu e-mail para a newsletter"
                  required
                  type="email"
                  maxLength={254}
                  value={newsletterEmail}
                  onChange={(event) => setNewsletterEmail(event.target.value)}
                  placeholder="Digite seu melhor e-mail"
                />
              </label>
              <button className="button button-primary" type="submit" disabled={newsletterBusy}>
                {newsletterBusy ? (
                  <LoaderCircle className="spin" size={18} />
                ) : (
                  <>
                    Cadastrar <ArrowRight size={15} />
                  </>
                )}
              </button>
            </form>
            {newsletterStatus ? (
              <p
                className={`newsletter-feedback ${
                  newsletterStatus.success ? "green-text" : "error-text"
                }`}
                role="status"
              >
                {newsletterStatus.success && <CheckCircle2 size={12} />} {newsletterStatus.message}
              </p>
            ) : (
              <p className="newsletter-consent">
                Garantimos a privacidade do seu e-mail.{" "}
                <button onClick={() => openDialog("privacy")}>Políticas de Privacidade</button>
              </p>
            )}
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="site-footer">
        <div className="page-width">
          <div className="footer-main">
            <div className="footer-brand">
              <Brand onClick={home} />
              <p>
                A melhor e mais barata loja de jogos para PlayStation 3, 4, 5 e Xbox do Brasil.
                <br />
                Pagamento via PIX com 5% OFF e cartão em até 12x.
              </p>
              <div className="footer-admin-tags">
                <button
                  className="footer-tool-btn"
                  onClick={() => openDialog("payment-settings")}
                >
                  <Settings size={13} /> Configurar Pagamentos & Gateways
                </button>
                <button
                  className="footer-tool-btn"
                  onClick={() => openDialog("admin-orders")}
                >
                  <Package size={13} /> Painel de Pedidos (Admin)
                </button>
                <button
                  className="footer-tool-btn highlight"
                  onClick={() => openDialog("publish-guide")}
                >
                  <Globe size={13} /> Guia de Publicação / Deploy
                </button>
              </div>
            </div>

            <div className="footer-column">
              <h3>Plataformas</h3>
              {filters.slice(1).map((item) => (
                <button key={item.id} onClick={() => chooseFilter(item.id)}>
                  {item.label}
                </button>
              ))}
            </div>

            <div className="footer-column">
              <h3>Sua Conta</h3>
              <button onClick={showOffers}>Super Ofertas</button>
              <button onClick={() => openDialog("reserve")}>Pré-Venda GTA VI</button>
              <button onClick={showFavorites}>Meus Favoritos</button>
              <button onClick={() => openDialog("profile")}>Meus Pedidos & Códigos</button>
            </div>

            <div className="footer-column">
              <h3>Atendimento</h3>
              <button onClick={() => openDialog("help")}>Central de Ajuda</button>
              <button onClick={() => openDialog("about")}>Sobre a Loja</button>
              <button onClick={() => openDialog("privacy")}>Privacidade & Termos</button>
              <span className="footer-safe">
                <ShieldCheck size={20} />
                <span>
                  Ambiente 100% Seguro.
                  <br />
                  <strong>Criptografia SSL 256-bit.</strong>
                </span>
              </span>
            </div>
          </div>

          <div className="footer-bottom">
            <span>© 2026 Nexus Games LTDA. Todos os direitos reservados. CNPJ: 45.192.839/0001-90</span>
            <span>
              PlayStation é marca registrada da Sony Interactive Ent. Xbox é marca registrada da
              Microsoft Corp.
            </span>
          </div>
        </div>
      </footer>

      {/* Floating Buttons */}
      <button
        className="support-float"
        onClick={() => openDialog("help")}
        aria-label="Abrir central de ajuda"
        title="Ajuda e Suporte"
      >
        <MessageCircle size={24} />
        <span />
      </button>

      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={20} />
          <span>{toast}</span>
          <button
            onClick={() => {
              setToast("");
              openDialog("cart");
            }}
          >
            Ver Carrinho <ArrowRight size={13} />
          </button>
          <button className="toast-close" onClick={() => setToast("")} aria-label="Fechar notificação">
            <X size={14} />
          </button>
        </div>
      )}

      {/* Dialogs */}
      <StoreDialogs
        dialog={dialog}
        onClose={closeDialog}
        setDialog={setDialog}
        cart={cart}
        onQuantity={updateQuantity}
        clearCart={() => setCart([])}
        profile={profile}
        saveProfile={setProfile}
      />

      {detailGame && (
        <ProductDetail
          key={detailGame.id}
          game={detailGame}
          initialPlatform={
            filter !== "all" && detailGame.platforms.includes(filter)
              ? filter
              : detailGame.platforms[0]
          }
          favorite={favorites.includes(detailGame.id)}
          onFavorite={() => toggleFavorite(detailGame.id)}
          onAdd={addToCart}
          onClose={closeDetail}
        />
      )}
    </>
  );
}

function GameCard({
  game,
  platform,
  favorite,
  onFavorite,
  onDetails,
  onAdd,
}: {
  game: Game;
  platform: Platform;
  favorite: boolean;
  onFavorite: () => void;
  onDetails: () => void;
  onAdd: (game: Game, platform: Platform) => void;
}) {
  const pixValue = pixPrice(game.price);

  return (
    <article className="game-card">
      <div className="game-art">
        <button
          className="game-cover-link"
          onClick={onDetails}
          aria-label={`Ver detalhes de ${game.title}`}
        >
          <Image
            src={game.image}
            alt={`Capa de ${game.title}`}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1000px) 33vw, 20vw"
          />
          <span className="cover-view">
            Ver Detalhes <ArrowRight size={15} />
          </span>
        </button>

        <span className={`game-platform ${platform === "Xbox" ? "platform-xbox" : ""}`}>
          <PlatformIcon platform={platform} size={12} />
          {platform === "Xbox" ? "XBOX" : platform}
        </span>

        <button
          className={`favorite-button ${favorite ? "is-favorite" : ""}`}
          onClick={onFavorite}
          aria-label={
            favorite ? `Remover ${game.title} dos favoritos` : `Salvar ${game.title} nos favoritos`
          }
          aria-pressed={favorite}
        >
          <Heart size={16} fill={favorite ? "currentColor" : "none"} />
        </button>

        <span className="discount-badge">-{discount(game)}%</span>
        {game.tag && (
          <span
            className={`game-tag ${
              game.tag.includes("PRÉ-VENDA")
                ? "tag-preorder"
                : game.tag.includes("EXCLUSIVO")
                ? "tag-exclusive"
                : game.tag.includes("LANÇAMENTO") || game.tag.includes("NOVIDADE")
                ? "tag-new"
                : ""
            }`}
          >
            {game.tag.includes("EM ALTA") && <Flame size={10} />} {game.tag}
          </span>
        )}
      </div>

      <div className="game-info">
        <button className="game-title" onClick={onDetails}>
          {game.title}
        </button>

        <div className="game-meta">
          <span>{game.genre}</span>
          <span className="game-rating" title="Avaliação dos jogadores">
            <Star size={10} fill="currentColor" />
            {game.rating}
          </span>
        </div>

        <div className="game-price-row">
          <div>
            <del>{money(game.originalPrice)}</del>
            <strong>{money(game.price)}</strong>
            <span className="pix-mini-price">
              <Zap size={10} /> {money(pixValue)} no PIX
            </span>
          </div>

          <button
            className="add-to-cart"
            onClick={() => onAdd(game, platform)}
            aria-label={`Adicionar ${game.title} para ${platform} ao carrinho`}
            title="Adicionar ao Carrinho"
          >
            <ShoppingCart size={17} />
            <PlusMark />
          </button>
        </div>
      </div>
    </article>
  );
}

function PlusMark() {
  return <span className="cart-plus">+</span>;
}
