"use client";

import { useCallback, useEffect, useState, type FormEvent } from "react";
import {
  CheckCircle2,
  Copy,
  Info,
  KeyRound,
  LoaderCircle,
  LockKeyhole,
  Package,
  RefreshCw,
  RotateCcw,
  ShieldAlert,
  Wallet,
  XCircle,
} from "lucide-react";
import { money } from "@/lib/catalog";

type AdminOrder = {
  code: string;
  name: string;
  email: string;
  cpf: string | null;
  items: { title: string; platform: string; quantity: number; price: number }[];
  total: number;
  paymentMethod: string;
  paymentStatus: string;
  provider: string;
  pixCode: string | null;
  paidAt: string | null;
  createdAt: string;
};

type Totals = {
  count: number;
  paidCount: number;
  pendingCount: number;
  revenueCents: number;
};

export function AdminOrdersPanel() {
  const [authed, setAuthed] = useState<boolean | null>(null);
  const [defaultToken, setDefaultToken] = useState(false);
  const [token, setToken] = useState("");
  const [loginBusy, setLoginBusy] = useState(false);
  const [error, setError] = useState("");

  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [totals, setTotals] = useState<Totals | null>(null);
  const [loading, setLoading] = useState(false);
  const [filter, setFilter] = useState<"pending" | "paid" | "all">("pending");
  const [actingOn, setActingOn] = useState("");
  const [copied, setCopied] = useState("");

  useEffect(() => {
    fetch("/api/admin/login")
      .then((r) => r.json())
      .then((d) => {
        setAuthed(!!d.authenticated);
        setDefaultToken(!!d.usingDefaultToken);
      })
      .catch(() => setAuthed(false));
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const r = await fetch(`/api/admin/orders?status=${filter}`);
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Erro ao carregar.");
      setOrders(d.orders);
      setTotals(d.totals);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erro ao carregar.");
    } finally {
      setLoading(false);
    }
  }, [filter]);

  useEffect(() => {
    if (authed) load();
  }, [authed, load]);

  async function login(e: FormEvent) {
    e.preventDefault();
    setLoginBusy(true);
    setError("");
    try {
      const r = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });
      const d = await r.json();
      if (!r.ok) throw new Error(d.error || "Senha incorreta.");
      setAuthed(true);
      setDefaultToken(!!d.usingDefaultToken);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Senha incorreta.");
    } finally {
      setLoginBusy(false);
    }
  }

  async function act(code: string, action: "confirm" | "cancel" | "reopen") {
    setActingOn(code + action);
    try {
      const r = await fetch("/api/admin/orders", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ code, action }),
      });
      if (r.ok) await load();
    } finally {
      setActingOn("");
    }
  }

  function copy(text: string, id: string) {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(""), 2000);
  }

  if (authed === null) {
    return (
      <div className="orders-loading">
        <LoaderCircle className="spin" size={24} /> Verificando acesso...
      </div>
    );
  }

  if (!authed) {
    return (
      <>
        <span className="dialog-eyebrow">
          <LockKeyhole size={18} /> ÁREA RESTRITA
        </span>
        <h2 id="dialog-title">Painel de Pedidos</h2>
        <p className="dialog-description">
          Aqui você acompanha as vendas e confirma manualmente os pagamentos recebidos via PIX.
        </p>

        <div className="password-hint">
          <KeyRound size={18} />
          <div>
            <strong>Senha padrão: nexus-admin</strong>
            <p>
              Antes de publicar, troque definindo <code>ADMIN_TOKEN</code> no servidor.
            </p>
          </div>
          <button
            type="button"
            className="button button-secondary"
            onClick={() => setToken("nexus-admin")}
          >
            Preencher
          </button>
        </div>

        <form className="dialog-form" onSubmit={login}>
          <label>
            Senha do painel
            <input
              type="password"
              required
              value={token}
              onChange={(e) => setToken(e.target.value)}
              placeholder="nexus-admin"
              autoFocus
            />
          </label>
          {error && (
            <p className="form-error" role="alert">
              <Info size={16} /> {error}
            </p>
          )}
          <button type="submit" className="button button-primary button-full" disabled={loginBusy}>
            {loginBusy ? <LoaderCircle size={16} className="spin" /> : <LockKeyhole size={16} />}
            Entrar no Painel
          </button>
        </form>

        <div className="notice">
          <ShieldAlert size={19} />
          <p>
            A senha padrão é <code>nexus-admin</code>. Antes de publicar, defina a variável{" "}
            <code>ADMIN_TOKEN</code> no seu servidor com uma senha forte — quem souber essa senha vê
            todos os seus pedidos.
          </p>
        </div>
      </>
    );
  }

  return (
    <>
      <span className="dialog-eyebrow">
        <Package size={18} /> GESTÃO DE VENDAS
      </span>
      <h2 id="dialog-title">Painel de Pedidos</h2>
      <p className="dialog-description">
        Confira no app do seu banco se o PIX caiu e marque o pedido como pago para liberar o jogo.
      </p>

      {defaultToken && (
        <div className="notice danger">
          <ShieldAlert size={19} />
          <p>
            <strong>Senha padrão em uso.</strong> Defina <code>ADMIN_TOKEN</code> nas variáveis de
            ambiente antes de publicar o site.
          </p>
        </div>
      )}

      {totals && (
        <div className="admin-stats">
          <div>
            <small>RECEBIDO</small>
            <strong className="green-text">{money(totals.revenueCents)}</strong>
          </div>
          <div>
            <small>PAGOS</small>
            <strong>{totals.paidCount}</strong>
          </div>
          <div>
            <small>AGUARDANDO</small>
            <strong className="orange-text">{totals.pendingCount}</strong>
          </div>
          <div>
            <small>TOTAL</small>
            <strong>{totals.count}</strong>
          </div>
        </div>
      )}

      <div className="admin-toolbar">
        <div className="admin-filters">
          {(
            [
              ["pending", "Aguardando"],
              ["paid", "Pagos"],
              ["all", "Todos"],
            ] as const
          ).map(([id, label]) => (
            <button
              key={id}
              className={`filter-button ${filter === id ? "selected" : ""}`}
              onClick={() => setFilter(id)}
            >
              {label}
            </button>
          ))}
        </div>
        <button className="button button-secondary refresh-btn" onClick={load} disabled={loading}>
          {loading ? <LoaderCircle size={14} className="spin" /> : <RefreshCw size={14} />}
          Atualizar
        </button>
      </div>

      {error && (
        <p className="form-error" role="alert">
          <Info size={16} /> {error}
        </p>
      )}

      {loading && !orders.length ? (
        <div className="orders-loading">
          <LoaderCircle className="spin" size={24} /> Carregando pedidos...
        </div>
      ) : !orders.length ? (
        <div className="orders-empty">
          <Wallet size={30} />
          <p>
            {filter === "pending"
              ? "Nenhum pedido aguardando pagamento."
              : filter === "paid"
              ? "Nenhum pedido pago ainda."
              : "Nenhum pedido recebido ainda."}
          </p>
        </div>
      ) : (
        <div className="admin-orders-list">
          {orders.map((o) => {
            const paid = !!o.paidAt;
            return (
              <article className={`admin-order ${paid ? "is-paid" : ""}`} key={o.code}>
                <header>
                  <div>
                    <strong>{o.code}</strong>
                    <span>
                      {new Date(o.createdAt).toLocaleString("pt-BR", {
                        day: "2-digit",
                        month: "2-digit",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                  <span className={`status-pill ${paid ? "status-approved" : "status-pending"}`}>
                    {o.paymentStatus}
                  </span>
                </header>

                <div className="admin-order-body">
                  <div className="admin-customer">
                    <strong>{o.name}</strong>
                    <span>{o.email}</span>
                    {o.cpf && <span>CPF {o.cpf}</span>}
                  </div>
                  <ul>
                    {o.items.map((it, i) => (
                      <li key={i}>
                        {it.quantity}× {it.title} <small>· {it.platform}</small>
                      </li>
                    ))}
                  </ul>
                </div>

                <footer>
                  <div className="admin-order-meta">
                    <span className="method-tag">
                      {o.paymentMethod === "pix"
                        ? "PIX"
                        : o.paymentMethod === "credit_card"
                        ? "Cartão"
                        : "Boleto"}
                      {o.provider !== "manual" && ` · ${o.provider}`}
                    </span>
                    <strong>{money(o.total)}</strong>
                  </div>

                  <div className="admin-actions">
                    {o.pixCode && (
                      <button
                        className="button button-secondary"
                        onClick={() => copy(o.pixCode!, o.code)}
                        title="Copiar código PIX"
                      >
                        {copied === o.code ? (
                          <CheckCircle2 size={14} className="green-text" />
                        ) : (
                          <Copy size={14} />
                        )}
                      </button>
                    )}
                    {!paid ? (
                      <>
                        <button
                          className="button button-primary"
                          onClick={() => act(o.code, "confirm")}
                          disabled={actingOn === o.code + "confirm"}
                        >
                          {actingOn === o.code + "confirm" ? (
                            <LoaderCircle size={14} className="spin" />
                          ) : (
                            <CheckCircle2 size={14} />
                          )}
                          Confirmar Pagamento
                        </button>
                        <button
                          className="button button-secondary"
                          onClick={() => act(o.code, "cancel")}
                          disabled={actingOn === o.code + "cancel"}
                          title="Cancelar pedido"
                        >
                          <XCircle size={14} />
                        </button>
                      </>
                    ) : (
                      <button
                        className="button button-secondary"
                        onClick={() => act(o.code, "reopen")}
                        disabled={actingOn === o.code + "reopen"}
                        title="Reabrir pedido"
                      >
                        <RotateCcw size={14} /> Reabrir
                      </button>
                    )}
                  </div>
                </footer>
              </article>
            );
          })}
        </div>
      )}
    </>
  );
}
