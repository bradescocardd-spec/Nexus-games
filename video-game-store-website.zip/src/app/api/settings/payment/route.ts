import { db } from "@/db";
import { paymentSettings } from "@/db/schema";
import { eq } from "drizzle-orm";
import { defaultPaymentSettings } from "@/lib/payment";
import { isAdmin, unauthorized } from "@/lib/admin";

export const dynamic = "force-dynamic";

/** Mostra só se a credencial existe, nunca o valor. */
function mask(value: string | null | undefined) {
  if (!value) return "";
  return `••••••••${value.slice(-4)}`;
}

export async function GET() {
  // Dados sensíveis (chave PIX, tokens) exigem autenticação de administrador.
  if (!(await isAdmin())) return unauthorized();

  try {
    const records = await db
      .select()
      .from(paymentSettings)
      .where(eq(paymentSettings.id, "default"))
      .limit(1);

    if (!records.length) {
      await db
        .insert(paymentSettings)
        .values({ id: "default", ...defaultPaymentSettings })
        .onConflictDoNothing();
      return Response.json({ settings: defaultPaymentSettings });
    }

    const r = records[0];
    return Response.json({
      settings: {
        gatewayMode: r.gatewayMode,
        pixKey: r.pixKey,
        pixKeyType: r.pixKeyType,
        pixDiscountPercent: r.pixDiscountPercent,
        merchantName: r.merchantName,
        merchantCity: r.merchantCity,
        maxInstallments: r.maxInstallments,
        freeInstallments: r.freeInstallments,
        // Credenciais nunca saem do servidor em texto puro.
        mercadoPagoPublicKey: r.mercadoPagoPublicKey ?? "",
        mercadoPagoAccessToken: mask(r.mercadoPagoAccessToken),
        stripePublishableKey: r.stripePublishableKey ?? "",
        stripeSecretKey: mask(r.stripeSecretKey),
        asaasApiKey: mask(r.asaasApiKey),
      },
    });
  } catch (err) {
    console.error("Payment settings GET error:", err);
    return Response.json({ settings: defaultPaymentSettings });
  }
}

export async function POST(request: Request) {
  if (!(await isAdmin())) return unauthorized();

  try {
    const body = await request.json();

    const existing = await db
      .select()
      .from(paymentSettings)
      .where(eq(paymentSettings.id, "default"))
      .limit(1);
    const prev = existing[0];

    /**
     * Se o campo voltou mascarado (o usuário não digitou nada novo),
     * mantemos a credencial que já estava salva.
     */
    const keepIfMasked = (incoming: unknown, saved: string | null | undefined) => {
      if (typeof incoming !== "string") return saved ?? "";
      const value = incoming.trim();
      if (!value) return "";
      if (value.startsWith("••••")) return saved ?? "";
      return value;
    };

    const clean = {
      gatewayMode: body.gatewayMode === "production" ? "production" : "sandbox",
      pixKey:
        typeof body.pixKey === "string" && body.pixKey.trim()
          ? body.pixKey.trim()
          : prev?.pixKey ?? defaultPaymentSettings.pixKey,
      pixKeyType: ["email", "cpf", "random"].includes(body.pixKeyType)
        ? body.pixKeyType
        : "email",
      pixDiscountPercent: Math.min(50, Math.max(0, Number(body.pixDiscountPercent) || 0)),
      merchantName:
        typeof body.merchantName === "string" && body.merchantName.trim()
          ? body.merchantName.trim().slice(0, 25).toUpperCase()
          : "NEXUS GAMES",
      merchantCity:
        typeof body.merchantCity === "string" && body.merchantCity.trim()
          ? body.merchantCity.trim().slice(0, 15).toUpperCase()
          : "SAO PAULO",
      mercadoPagoPublicKey:
        typeof body.mercadoPagoPublicKey === "string"
          ? body.mercadoPagoPublicKey.trim()
          : "",
      mercadoPagoAccessToken: keepIfMasked(
        body.mercadoPagoAccessToken,
        prev?.mercadoPagoAccessToken
      ),
      stripePublishableKey:
        typeof body.stripePublishableKey === "string"
          ? body.stripePublishableKey.trim()
          : "",
      stripeSecretKey: keepIfMasked(body.stripeSecretKey, prev?.stripeSecretKey),
      asaasApiKey: keepIfMasked(body.asaasApiKey, prev?.asaasApiKey),
      maxInstallments: Math.min(12, Math.max(1, Number(body.maxInstallments) || 12)),
      freeInstallments: Math.min(12, Math.max(1, Number(body.freeInstallments) || 6)),
      updatedAt: new Date(),
    };

    await db
      .insert(paymentSettings)
      .values({ id: "default", ...clean })
      .onConflictDoUpdate({ target: paymentSettings.id, set: clean });

    return Response.json({
      success: true,
      message: "Configurações de pagamento atualizadas com sucesso.",
    });
  } catch (err) {
    console.error("Payment settings POST error:", err);
    return Response.json({ error: "Não foi possível salvar as configurações." }, { status: 500 });
  }
}
