import { resolvePaymentConfig, testAsaas, testMercadoPago, testStripe } from "@/lib/gateways";
import { isAdmin, unauthorized } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  if (!(await isAdmin())) return unauthorized();

  try {
    const body = await request.json().catch(() => ({}));
    const config = await resolvePaymentConfig();

    // Valores mascarados vindos da tela não são credenciais: usa a salva.
    const pick = (fromBody: unknown, fallback: string) => {
      if (typeof fromBody !== "string") return fallback;
      const value = fromBody.trim();
      if (!value || value.startsWith("••••")) return fallback;
      return value;
    };

    const mpToken = pick(body.mercadoPagoAccessToken, config.mpToken);
    const stripeSecret = pick(body.stripeSecretKey, config.stripeSecret);
    const asaasKey = pick(body.asaasApiKey, config.asaasKey);
    const mode = pick(body.gatewayMode, config.gatewayMode);

    const results: {
      provider: string;
      label: string;
      ok: boolean;
      detail: string;
      live?: boolean;
    }[] = [];

    if (asaasKey) {
      const as = await testAsaas(asaasKey, mode);
      results.push({
        provider: "asaas",
        label: "Asaas",
        ok: as.ok,
        detail: as.ok ? `Conectado: ${as.account}` : as.error,
        live: as.ok ? as.live : undefined,
      });
    }

    if (mpToken) {
      const mp = await testMercadoPago(mpToken);
      results.push({
        provider: "mercadopago",
        label: "Mercado Pago",
        ok: mp.ok,
        detail: mp.ok ? `Conectado como ${mp.account}` : mp.error,
        live: mp.ok ? mp.live : undefined,
      });
    }

    if (stripeSecret) {
      const st = await testStripe(stripeSecret);
      results.push({
        provider: "stripe",
        label: "Stripe",
        ok: st.ok,
        detail: st.ok ? st.account : st.error,
        live: st.ok ? st.live : undefined,
      });
    }

    if (!results.length) {
      results.push({
        provider: "manual",
        label: "PIX Direto (sem gateway)",
        ok: true,
        detail: `Funcionando. Os QR Codes são gerados com a chave ${config.pixKeyEffective} e o dinheiro cai direto na sua conta. Confirme os pedidos em "Meus Pedidos / Admin".`,
      });
    }

    return Response.json({
      results,
      credentialSource: config.credentialSource,
      gatewayMode: config.gatewayMode,
      activeProvider: config.provider,
    });
  } catch {
    return Response.json({ error: "Não foi possível testar as credenciais." }, { status: 500 });
  }
}
