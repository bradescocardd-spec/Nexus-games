import { resolvePaymentConfig } from "@/lib/gateways";

export const dynamic = "force-dynamic";

/**
 * Dados NÃO sensíveis usados pelo checkout.
 * Nunca retorna chave PIX, tokens ou segredos.
 */
export async function GET() {
  try {
    const config = await resolvePaymentConfig();
    const hasGateway = config.provider !== "manual";

    return Response.json({
      pixDiscountPercent: config.pixDiscountPercent,
      maxInstallments: config.maxInstallments,
      freeInstallments: config.freeInstallments,
      gatewayMode: config.gatewayMode,
      // Sem gateway só o PIX direto é real; cartão e boleto exigem processadora.
      methods: {
        pix: true,
        credit_card: hasGateway,
        boleto: config.provider === "asaas" || config.provider === "mercadopago",
      },
    });
  } catch {
    return Response.json({
      pixDiscountPercent: 5,
      maxInstallments: 12,
      freeInstallments: 6,
      gatewayMode: "sandbox",
      methods: { pix: true, credit_card: false, boleto: false },
    });
  }
}
