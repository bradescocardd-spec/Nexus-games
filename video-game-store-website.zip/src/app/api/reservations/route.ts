import { db } from "@/db";
import { reservations } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    if (name.length < 2 || name.length > 100 || email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || body.consent !== true) {
      return Response.json({ error: "Preencha nome, e-mail e aceite as condições da reserva." }, { status: 400 });
    }
    const code = `GTA-${crypto.randomUUID().replaceAll("-", "").slice(0, 8).toUpperCase()}`;
    const saved = await db.insert(reservations).values({ name, email, code }).onConflictDoNothing({ target: reservations.email }).returning({ code: reservations.code });
    return Response.json({ code: saved[0]?.code ?? null, message: saved.length ? "Interesse registrado! Sua reserva para PS5 foi salva, sem cobrança." : "Seu interesse já está registrado com este e-mail. Não houve nova cobrança." }, { status: saved.length ? 201 : 200 });
  } catch {
    return Response.json({ error: "Não foi possível registrar sua reserva. Tente novamente." }, { status: 500 });
  }
}
