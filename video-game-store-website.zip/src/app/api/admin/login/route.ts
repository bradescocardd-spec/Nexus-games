import {
  adminToken,
  clearAdminCookie,
  isAdmin,
  setAdminCookie,
  usingDefaultToken,
} from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET() {
  return Response.json({
    authenticated: await isAdmin(),
    usingDefaultToken: usingDefaultToken(),
  });
}

export async function POST(request: Request) {
  const body = await request.json().catch(() => ({}));
  const token = typeof body.token === "string" ? body.token.trim() : "";

  if (!token || token !== adminToken()) {
    return Response.json({ error: "Senha incorreta." }, { status: 401 });
  }

  await setAdminCookie(token);
  return Response.json({
    authenticated: true,
    usingDefaultToken: usingDefaultToken(),
  });
}

export async function DELETE() {
  await clearAdminCookie();
  return Response.json({ authenticated: false });
}
