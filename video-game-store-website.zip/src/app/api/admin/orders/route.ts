import { db } from "@/db";
import { orders } from "@/db/schema";
import { desc, eq } from "drizzle-orm";
import { isAdmin, unauthorized } from "@/lib/admin";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!(await isAdmin())) return unauthorized();

  try {
    const filter = new URL(request.url).searchParams.get("status");

    const rows = await db
      .select({
        code: orders.code,
        name: orders.name,
        email: orders.email,
        cpf: orders.cpf,
        items: orders.items,
        subtotal: orders.subtotal,
        discountAmount: orders.discountAmount,
        total: orders.total,
        paymentMethod: orders.paymentMethod,
        paymentStatus: orders.paymentStatus,
        installments: orders.installments,
        cardBrand: orders.cardBrand,
        cardLast4: orders.cardLast4,
        pixCode: orders.pixCode,
        provider: orders.provider,
        providerUrl: orders.providerUrl,
        paidAt: orders.paidAt,
        adminNote: orders.adminNote,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .orderBy(desc(orders.createdAt))
      .limit(200);

    const list =
      filter === "pending"
        ? rows.filter((o) => !o.paidAt && !o.paymentStatus.includes("Cancel"))
        : filter === "paid"
        ? rows.filter((o) => !!o.paidAt)
        : rows;

    const totals = {
      count: rows.length,
      paidCount: rows.filter((o) => o.paidAt).length,
      pendingCount: rows.filter((o) => !o.paidAt && !o.paymentStatus.includes("Cancel")).length,
      revenueCents: rows.filter((o) => o.paidAt).reduce((s, o) => s + o.total, 0),
    };

    return Response.json({ orders: list, totals });
  } catch (error) {
    console.error("Admin orders error:", error);
    return Response.json({ error: "Erro ao carregar pedidos." }, { status: 500 });
  }
}

export async function PATCH(request: Request) {
  if (!(await isAdmin())) return unauthorized();

  try {
    const body = await request.json();
    const code = typeof body.code === "string" ? body.code.trim() : "";
    const action = body.action;

    if (!code) return Response.json({ error: "Código obrigatório." }, { status: 400 });

    const note = typeof body.note === "string" ? body.note.slice(0, 500) : undefined;

    if (action === "confirm") {
      await db
        .update(orders)
        .set({
          paymentStatus: "Pagamento Confirmado Manualmente",
          paidAt: new Date(),
          ...(note !== undefined ? { adminNote: note } : {}),
        })
        .where(eq(orders.code, code));
      return Response.json({ success: true, message: "Pedido marcado como pago." });
    }

    if (action === "cancel") {
      await db
        .update(orders)
        .set({
          paymentStatus: "Pagamento Cancelado",
          paidAt: null,
          ...(note !== undefined ? { adminNote: note } : {}),
        })
        .where(eq(orders.code, code));
      return Response.json({ success: true, message: "Pedido cancelado." });
    }

    if (action === "reopen") {
      await db
        .update(orders)
        .set({ paymentStatus: "Aguardando Pagamento PIX", paidAt: null })
        .where(eq(orders.code, code));
      return Response.json({ success: true, message: "Pedido reaberto." });
    }

    return Response.json({ error: "Ação inválida." }, { status: 400 });
  } catch (error) {
    console.error("Admin patch error:", error);
    return Response.json({ error: "Erro ao atualizar o pedido." }, { status: 500 });
  }
}
