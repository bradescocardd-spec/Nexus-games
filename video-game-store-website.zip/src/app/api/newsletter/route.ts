import { db } from "@/db";
import { subscribers } from "@/db/schema";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    if (email.length > 254 || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return Response.json({ error: "Digite um e-mail válido para se inscrever." }, { status: 400 });
    await db.insert(subscribers).values({ email }).onConflictDoNothing();
    return Response.json({ message: "Você está na lista! Sua inscrição foi salva com sucesso." });
  } catch {
    return Response.json({ error: "Não foi possível concluir sua inscrição. Tente novamente." }, { status: 500 });
  }
}
