import { cookies } from "next/headers";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { orders, type OrderItem } from "@/db/schema";
import { games, type Platform } from "@/lib/catalog";
import { generatePixPayload, detectCardBrand, generateRealQrBase64 } from "@/lib/payment";
import {
  createAsaasPix,
  createMercadoPagoPix,
  createStripePaymentIntent,
  getAsaasPaymentStatus,
  resolvePaymentConfig,
} from "@/lib/gateways";

export const dynamic = "force-dynamic";
const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const validUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export async function GET() {
  try {
    const session = (await cookies()).get("nexus_session")?.value;
    if (!session || !validUuid.test(session)) return Response.json({ orders: [] });

    const result = await db
      .select({
        code: orders.code,
        items: orders.items,
        subtotal: orders.subtotal,
        discountAmount: orders.discountAmount,
        total: orders.total,
        paymentMethod: orders.paymentMethod,
        paymentStatus: orders.paymentStatus,
        installments: orders.installments,
        cardLast4: orders.cardLast4,
        cardBrand: orders.cardBrand,
        pixCode: orders.pixCode,
        boletoCode: orders.boletoCode,
        provider: orders.provider,
        providerUrl: orders.providerUrl,
        createdAt: orders.createdAt,
      })
      .from(orders)
      .where(eq(orders.sessionId, session))
      .orderBy(desc(orders.createdAt))
      .limit(30);

    return Response.json({ orders: result });
  } catch {
    return Response.json(
      { error: "Não foi possível carregar os pedidos. Tente novamente." },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const name = typeof body.name === "string" ? body.name.trim() : "";
    const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
    const cpf = typeof body.cpf === "string" ? body.cpf.trim() : "";
    const paymentMethod = ["pix", "credit_card", "boleto"].includes(body.paymentMethod)
      ? (body.paymentMethod as "pix" | "credit_card" | "boleto")
      : "pix";

    if (name.length < 2 || name.length > 100 || email.length > 254 || !validEmail.test(email)) {
      return Response.json({ error: "Informe seu nome e um e-mail válido." }, { status: 400 });
    }

    if (!Array.isArray(body.items) || !body.items.length || body.items.length > 30) {
      return Response.json({ error: "Adicione pelo menos um jogo ao carrinho." }, { status: 400 });
    }

    const items: OrderItem[] = [];
    for (const item of body.items) {
      if (!item || typeof item !== "object") {
        return Response.json({ error: "Item inválido." }, { status: 400 });
      }
      const game = games.find((g) => g.id === item.gameId);
      if (
        !game ||
        !game.platforms.includes(item.platform as Platform) ||
        !Number.isInteger(item.quantity) ||
        item.quantity < 1 ||
        item.quantity > 10
      ) {
        return Response.json(
          { error: "Há um jogo, console ou quantidade inválida no carrinho." },
          { status: 400 }
        );
      }
      items.push({
        gameId: game.id,
        title: game.title,
        platform: item.platform,
        quantity: item.quantity,
        price: game.price,
      });
    }

    const config = await resolvePaymentConfig();
    const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
    const discountPercent = paymentMethod === "pix" ? config.pixDiscountPercent : 0;
    const discountAmount = Math.round((subtotal * discountPercent) / 100);
    const total = Math.max(0, subtotal - discountAmount);

    const jar = await cookies();
    const previousSession = jar.get("nexus_session")?.value;
    const sessionId =
      previousSession && validUuid.test(previousSession) ? previousSession : crypto.randomUUID();

    const code = `NX-${crypto.randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}`;
    const description = items.map((i) => `${i.quantity}x ${i.title}`).join(", ");

    let pixCode: string | null = null;
    let boletoCode: string | null = null;
    let cardLast4: string | null = null;
    let cardBrand: string | null = null;
    let installments = 1;
    let paymentStatus = "Aguardando Pagamento";
    let provider = "manual";
    let providerPaymentId: string | null = null;
    let providerQrBase64: string | null = null;
    let providerUrl: string | null = null;
    let gatewayWarning: string | null = null;

    if (paymentMethod === "pix") {
      // 1) Tenta o Mercado Pago quando há credencial configurada.
      if (config.mpToken) {
        const mp = await createMercadoPagoPix({
          token: config.mpToken,
          amountCents: total,
          description,
          email,
          firstName: name,
          cpf,
          orderCode: code,
        });

        if (mp.ok) {
          provider = "mercadopago";
          providerPaymentId = mp.providerPaymentId;
          pixCode = mp.qrCode;
          providerQrBase64 = mp.qrCodeBase64;
          providerUrl = mp.ticketUrl;
          paymentStatus = "Aguardando Pagamento PIX";
        } else {
          gatewayWarning = mp.error;
        }
      }

      // 2) Asaas (abre conta só com CPF) quando houver chave configurada.
      if (!pixCode && config.asaasKey) {
        const asaas = await createAsaasPix({
          key: config.asaasKey,
          mode: config.gatewayMode,
          amountCents: total,
          description,
          name,
          email,
          cpf,
          orderCode: code,
        });

        if (asaas.ok) {
          provider = "asaas";
          providerPaymentId = asaas.providerPaymentId;
          pixCode = asaas.qrCode;
          providerQrBase64 = asaas.qrCodeBase64;
          providerUrl = asaas.ticketUrl;
          paymentStatus = "Aguardando Pagamento PIX";
        } else {
          gatewayWarning = asaas.error;
        }
      }

      // 3) Fallback: BR Code gerado localmente com a chave PIX cadastrada.
      if (!pixCode) {
        pixCode = generatePixPayload(
          config.pixKeyEffective,
          config.merchantName,
          config.merchantCity,
          total,
          code
        );
        paymentStatus = "Aguardando Pagamento PIX";
      }

      // QR Code real e escaneável a partir do payload PIX.
      if (pixCode && !providerQrBase64) {
        providerQrBase64 = await generateRealQrBase64(pixCode);
      }
    } else if (paymentMethod === "boleto") {
      // Boleto real exige emissor bancário. Sem gateway, não há como gerar.
      return Response.json(
        {
          error:
            "Boleto indisponível no momento. Conecte uma gateway (Asaas ou Mercado Pago) para emitir boletos válidos, ou finalize no PIX.",
        },
        { status: 400 }
      );
    } else {
      /*
       * Sem processadora não existe cobrança de cartão: o pedido ficaria
       * "aprovado" sem nenhum dinheiro entrar. Além disso, receber número e
       * CVV no próprio servidor exige certificação PCI-DSS.
       */
      if (!config.stripeSecret) {
        return Response.json(
          {
            error:
              "Pagamento com cartão indisponível no momento. Conecte uma gateway nas configurações, ou finalize no PIX com desconto.",
          },
          { status: 400 }
        );
      }

      const cardNum = typeof body.cardNumber === "string" ? body.cardNumber.replace(/\D/g, "") : "";
      cardLast4 = cardNum.slice(-4) || null;
      cardBrand = detectCardBrand(cardNum);
      installments = Math.max(
        1,
        Math.min(config.maxInstallments, Number(body.installments) || 1)
      );

      const intent = await createStripePaymentIntent({
        secret: config.stripeSecret,
        amountCents: total,
        description,
        email,
        orderCode: code,
      });

      if (intent.ok) {
        provider = "stripe";
        providerPaymentId = intent.providerPaymentId;
        paymentStatus = "Aguardando Confirmação do Cartão";
      } else {
        return Response.json({ error: intent.error }, { status: 502 });
      }
    }

    await db.insert(orders).values({
      code,
      sessionId,
      name,
      email,
      cpf: cpf || null,
      items,
      subtotal,
      discountAmount,
      total,
      paymentMethod,
      paymentStatus,
      installments,
      cardLast4,
      cardBrand,
      pixCode,
      boletoCode,
      provider,
      providerPaymentId,
      providerQrBase64,
      providerUrl,
    });

    jar.set("nexus_session", sessionId, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 90,
      path: "/",
    });

    return Response.json(
      {
        code,
        subtotal,
        discountAmount,
        discountPercent,
        total,
        paymentMethod,
        paymentStatus,
        pixCode,
        boletoCode,
        installments,
        cardLast4,
        cardBrand,
        provider,
        providerQrBase64,
        providerUrl,
        gatewayMode: config.gatewayMode,
        isLive: config.isLive,
        gatewayWarning,
        message:
          paymentMethod === "credit_card"
            ? provider === "stripe"
              ? "Cobrança criada na Stripe. Finalize a confirmação do cartão."
              : "Pedido de cartão registrado."
            : paymentMethod === "pix"
            ? provider === "mercadopago"
              ? "PIX oficial gerado pelo Mercado Pago."
              : `Código PIX gerado com ${discountPercent}% de desconto.`
            : "Boleto bancário gerado com sucesso.",
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Order creation error:", error);
    return Response.json(
      { error: "Não foi possível salvar o pedido. Tente novamente." },
      { status: 500 }
    );
  }
}

/** Consulta/atualiza o status do pagamento de um pedido. */
export async function PUT(request: Request) {
  try {
    const { code, simulate } = await request.json();
    if (!code || typeof code !== "string") {
      return Response.json({ error: "Código do pedido obrigatório." }, { status: 400 });
    }

    const rows = await db.select().from(orders).where(eq(orders.code, code)).limit(1);
    if (!rows.length) {
      return Response.json({ error: "Pedido não encontrado." }, { status: 404 });
    }
    const order = rows[0];
    const config = await resolvePaymentConfig();

    // Consulta real no Mercado Pago quando o pagamento foi criado lá.
    if (order.provider === "mercadopago" && order.providerPaymentId && config.mpToken) {
      try {
        const response = await fetch(
          `https://api.mercadopago.com/v1/payments/${order.providerPaymentId}`,
          {
            headers: { Authorization: `Bearer ${config.mpToken}` },
            signal: AbortSignal.timeout(12000),
          }
        );
        const data = await response.json();
        if (response.ok) {
          const approved = data.status === "approved";
          const status = approved
            ? "PIX Confirmado com Sucesso"
            : data.status === "cancelled"
            ? "Pagamento Cancelado"
            : "Aguardando Pagamento PIX";
          await db.update(orders).set({ paymentStatus: status }).where(eq(orders.code, code));
          return Response.json({ success: true, approved, paymentStatus: status });
        }
      } catch {
        /* segue para resposta padrão */
      }
      return Response.json({
        success: true,
        approved: false,
        paymentStatus: order.paymentStatus,
      });
    }

    // Consulta real no Asaas.
    if (order.provider === "asaas" && order.providerPaymentId && config.asaasKey) {
      const res = await getAsaasPaymentStatus(
        config.asaasKey,
        config.gatewayMode,
        order.providerPaymentId
      );
      if (res.ok) {
        const approved = ["RECEIVED", "CONFIRMED", "RECEIVED_IN_CASH"].includes(res.status);
        const status = approved
          ? "PIX Confirmado com Sucesso"
          : res.status === "REFUNDED"
          ? "Pagamento Estornado"
          : "Aguardando Pagamento PIX";
        await db
          .update(orders)
          .set({ paymentStatus: status, ...(approved ? { paidAt: new Date() } : {}) })
          .where(eq(orders.code, code));
        return Response.json({ success: true, approved, paymentStatus: status });
      }
      return Response.json({
        success: true,
        approved: false,
        paymentStatus: order.paymentStatus,
      });
    }

    // Simulação só é permitida fora do modo produção.
    if (simulate === true && config.gatewayMode !== "production") {
      const status = "PIX Confirmado com Sucesso";
      await db
        .update(orders)
        .set({ paymentStatus: status, paidAt: new Date() })
        .where(eq(orders.code, code));
      return Response.json({ success: true, approved: true, paymentStatus: status });
    }

    return Response.json({
      success: true,
      approved: order.paymentStatus.includes("Confirmado"),
      paymentStatus: order.paymentStatus,
      note:
        simulate === true
          ? "A simulação está desativada no modo produção."
          : undefined,
    });
  } catch {
    return Response.json({ error: "Erro ao consultar o pagamento." }, { status: 500 });
  }
}
