import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";
import { resolvePaymentConfig } from "@/lib/gateways";

export const dynamic = "force-dynamic";

/**
 * Webhook de notificações do Mercado Pago.
 * Configure esta URL no painel do Mercado Pago:
 *   https://SEU-DOMINIO/api/webhooks/mercadopago
 */
export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const url = new URL(request.url);

    const paymentId =
      body?.data?.id ||
      body?.resource?.toString().split("/").pop() ||
      url.searchParams.get("data.id") ||
      url.searchParams.get("id");

    if (!paymentId) {
      return Response.json({ received: true, ignored: "sem id de pagamento" });
    }

    const config = await resolvePaymentConfig();
    if (!config.mpToken) {
      return Response.json({ received: true, ignored: "gateway não configurado" });
    }

    const response = await fetch(`https://api.mercadopago.com/v1/payments/${paymentId}`, {
      headers: { Authorization: `Bearer ${config.mpToken}` },
      signal: AbortSignal.timeout(12000),
    });

    if (!response.ok) {
      return Response.json({ received: true, ignored: "pagamento não encontrado" });
    }

    const payment = await response.json();
    const orderCode: string | undefined = payment?.external_reference;
    if (!orderCode) {
      return Response.json({ received: true, ignored: "sem external_reference" });
    }

    const status =
      payment.status === "approved"
        ? "PIX Confirmado com Sucesso"
        : payment.status === "cancelled" || payment.status === "rejected"
        ? "Pagamento Cancelado"
        : "Aguardando Pagamento PIX";

    await db.update(orders).set({ paymentStatus: status }).where(eq(orders.code, orderCode));

    return Response.json({ received: true, orderCode, status });
  } catch (error) {
    console.error("Mercado Pago webhook error:", error);
    // Responder 200 evita reenvios infinitos do provedor.
    return Response.json({ received: true, error: true });
  }
}

export async function GET() {
  return Response.json({
    ok: true,
    endpoint: "webhook Mercado Pago ativo",
    uso: "Cadastre esta URL em Suas integrações > Webhooks > Pagamentos",
  });
}
