import { db } from "@/db";
import { orders } from "@/db/schema";
import { eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

/**
 * Webhook de eventos da Stripe.
 * Configure esta URL no painel da Stripe:
 *   https://SEU-DOMINIO/api/webhooks/stripe
 */
export async function POST(request: Request) {
  try {
    const event = await request.json().catch(() => null);
    if (!event?.type) {
      return Response.json({ received: true, ignored: "evento inválido" });
    }

    const object = event?.data?.object ?? {};
    const orderCode: string | undefined =
      object?.metadata?.order_code || object?.client_reference_id;

    if (!orderCode) {
      return Response.json({ received: true, ignored: "sem order_code" });
    }

    let status: string | null = null;
    if (event.type === "payment_intent.succeeded" || event.type === "checkout.session.completed") {
      status = "Pagamento Confirmado com Sucesso";
    } else if (event.type === "payment_intent.payment_failed") {
      status = "Pagamento Recusado";
    } else if (event.type === "charge.refunded") {
      status = "Pagamento Estornado";
    }

    if (status) {
      await db.update(orders).set({ paymentStatus: status }).where(eq(orders.code, orderCode));
    }

    return Response.json({ received: true, orderCode, status });
  } catch (error) {
    console.error("Stripe webhook error:", error);
    return Response.json({ received: true, error: true });
  }
}

export async function GET() {
  return Response.json({
    ok: true,
    endpoint: "webhook Stripe ativo",
    uso: "Cadastre esta URL em Developers > Webhooks",
  });
}
