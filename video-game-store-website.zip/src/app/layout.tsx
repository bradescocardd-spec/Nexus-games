import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  title: "Nexus Games | Seu próximo game começa aqui",
  description: "Explore jogos de PS3, PS4, PS5 e Xbox. Lançamentos, clássicos, ofertas e reserva de interesse para Grand Theft Auto VI no PS5. Loja demonstrativa, sem cobranças.",
  applicationName: "Nexus Games",
  icons: { icon: "/icon.svg" },
  openGraph: { title: "Nexus Games — O próximo play é seu.", description: "Seu universo de jogos para PlayStation e Xbox. Conheça os lançamentos e a pré-venda do GTA VI para PS5.", locale: "pt_BR", type: "website", images: [{ url: "/images/gta-hero.webp", width: 1800, height: 923 }] },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
