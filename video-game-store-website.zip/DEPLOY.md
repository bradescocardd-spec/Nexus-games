# Publicar a Nexus Games e integrar sua gateway

Guia rápido para colocar a loja no ar com domínio próprio e receber pagamentos
na sua própria conta.

---

## 1. Banco de dados (2 min)

1. Crie uma conta gratuita no [Neon](https://neon.tech) ou [Supabase](https://supabase.com).
2. Crie um projeto PostgreSQL.
3. Copie a *connection string* (começa com `postgresql://`).

## 2. Publicar na Vercel (5 min)

1. Suba este projeto para um repositório no GitHub.
2. Acesse [vercel.com](https://vercel.com) → **Add New → Project** → importe o repositório.
3. A Vercel detecta o Next.js automaticamente. Clique em **Deploy**.

## 3. Variáveis de ambiente

Em **Settings → Environment Variables**, cadastre o conteúdo de `.env.example`
com os seus dados reais. No mínimo:

| Variável | Obrigatória | Para quê |
|---|---|---|
| `DATABASE_URL` | Sim | Pedidos, reservas e configurações |
| `NEXT_PUBLIC_SITE_URL` | Recomendada | Metadados e links |
| `MERCADO_PAGO_ACCESS_TOKEN` | Para PIX automático | Gera o PIX oficial |
| `STRIPE_SECRET_KEY` | Para cartão | Cria a cobrança no cartão |
| `PIX_CHAVE_PADRAO` | Opcional | PIX manual sem gateway |

> As variáveis de ambiente **têm prioridade** sobre as chaves salvas no painel
> do site — é a forma mais segura em produção.

## 4. Criar as tabelas

Com a `DATABASE_URL` de produção no `.env` local, rode:

```bash
npx drizzle-kit push
```

## 5. Domínio próprio

Em **Settings → Domains**, adicione seu domínio. O certificado SSL é emitido
automaticamente.

## 6. Como você recebe o dinheiro

### Opção A — PIX Direto (sem gateway, funciona hoje)

É o padrão. O QR Code é gerado com a **sua chave PIX** e o dinheiro cai
**direto no seu banco**, sem intermediário e sem taxa.

> Funciona com qualquer banco (Sicoob, Bradesco, Nubank, Caixa...). O padrão
> PIX é do Banco Central: o que importa é a chave, não a instituição. Se a
> chave for do tipo e-mail, o texto do e-mail não tem relação com o banco.

**Importante:** sem gateway, apenas o PIX fica disponível no checkout. Cartão e
boleto exigem uma processadora — sem ela não há como cobrar no cartão nem
emitir um boleto pagável.

Fluxo do dia a dia:
1. Cliente paga o PIX.
2. Você confere no app do banco se o valor caiu.
3. Abre **Meus Pedidos (Admin)** no site e clica em *Confirmar Pagamento*.
4. Entrega o jogo para o cliente.

> A conferência é manual — não existe baixa automática sem gateway.

### Opção B — Asaas (abre com CPF, sem CNPJ)

Se quiser **baixa automática**, o Asaas é o caminho mais simples para pessoa
física. Crie a conta, pegue a chave em *Integrações → API* e cole no painel
*Configurar Pagamento → Gateway automática*.

### Opção C — Mercado Pago ou Stripe

Também suportados, caso você venha a ter conta.

### Webhooks (só se usar gateway)

Cadastre, trocando pelo seu domínio:

- Mercado Pago → *Suas integrações → Webhooks → Pagamentos*
  `https://seudominio.com.br/api/webhooks/mercadopago`
- Stripe → *Developers → Webhooks* (evento `payment_intent.succeeded`)
  `https://seudominio.com.br/api/webhooks/stripe`

## 6.1. Proteja o painel admin

Defina `ADMIN_TOKEN` com uma senha forte **antes de publicar**. A senha padrão
é `nexus-admin`, e quem souber dela vê nome, e-mail e CPF dos seus clientes.

### Webhooks (baixa automática)

Cadastre na sua gateway, trocando pelo seu domínio:

- Mercado Pago → *Suas integrações → Webhooks → Pagamentos*
  `https://seudominio.com.br/api/webhooks/mercadopago`
- Stripe → *Developers → Webhooks* (evento `payment_intent.succeeded`)
  `https://seudominio.com.br/api/webhooks/stripe`

Sem webhook o pagamento ainda funciona: o cliente pode clicar em
**"Já paguei, verificar agora"** e o sistema consulta a gateway na hora.

## 7. Trocar para produção

No painel *Configurar Pagamento*, marque **Modo Produção**. Isso bloqueia o
botão de simular aprovação e passa a valer dinheiro real.

---

## Antes de vender de verdade

- Use credenciais `APP_USR-` / `sk_live_` (não as de teste).
- Confirme que você tem **autorização para revender** as licenças dos jogos.
- Publique CNPJ, política de trocas, reembolso e prazo de arrependimento de 7
  dias (Código de Defesa do Consumidor).
- Os preços e descontos do catálogo são exemplos — ajuste em `src/lib/catalog.ts`.
